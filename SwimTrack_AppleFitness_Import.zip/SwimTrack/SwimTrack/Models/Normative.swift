import Foundation

/// Нормативы по одной дисциплине (дистанция + способ + бассейн + пол).
/// Если какого-то разряда в источнике нет или значение повреждено,
/// его просто нет в словаре `ranks`.
struct Normative: Codable, Hashable {
    let distance: Int
    let stroke: Stroke
    let pool: Pool
    let gender: Gender
    /// Время норматива в миллисекундах.
    let ranks: [Rank: Int]

    /// Ключ для быстрого поиска.
    static func key(distance: Int, stroke: Stroke, pool: Pool, gender: Gender) -> String {
        "\(gender.rawValue)-\(pool.rawValue)-\(stroke.rawValue)-\(distance)"
    }

    var key: String {
        Normative.key(distance: distance, stroke: stroke, pool: pool, gender: gender)
    }
}
