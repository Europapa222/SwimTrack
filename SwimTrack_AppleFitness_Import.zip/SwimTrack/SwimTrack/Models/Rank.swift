import Foundation

/// Спортивные разряды и звания. Порядок объявления = порядок от высшего к низшему
/// и совпадает с порядком колонок в таблицах источника (МСМК … III(ю)).
enum Rank: String, CaseIterable, Codable, Hashable {
    case msmk = "МСМК"
    case ms = "МС"
    case kms = "КМС"
    case first = "I"
    case second = "II"
    case third = "III"
    case firstYouth = "I(ю)"
    case secondYouth = "II(ю)"
    case thirdYouth = "III(ю)"

    /// Минимальный возраст присвоения звания (nil — ограничения нет).
    /// КМС — с 10 лет, МС — с 12, МСМК — с 14.
    var minimumAge: Int? {
        switch self {
        case .kms: return 10
        case .ms: return 12
        case .msmk: return 14
        default: return nil
        }
    }

    /// Родительный падеж — для фразы «до I разряда не хватает …».
    var genitive: String {
        switch self {
        case .msmk: return "МСМК"
        case .ms: return "МС"
        case .kms: return "КМС"
        case .first: return "I разряда"
        case .second: return "II разряда"
        case .third: return "III разряда"
        case .firstYouth: return "I юношеского разряда"
        case .secondYouth: return "II юношеского разряда"
        case .thirdYouth: return "III юношеского разряда"
        }
    }

    /// Порядок колонок в таблицах источника.
    static let columnOrder: [Rank] = Rank.allCases
}
