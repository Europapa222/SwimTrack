import Foundation

/// Результат заплыва, введённый пользователем.
struct SwimResult: Identifiable, Codable, Equatable {
    var id = UUID()
    var distance: Int
    var stroke: Stroke
    var pool: Pool
    /// Время в миллисекундах (точность источника — сотые, т.е. кратно 10).
    var timeMs: Int
    var date: Date
    var competition: String
    var gender: Gender

    /// «100 м · Вольный стиль»
    var eventTitle: String { "\(distance) м · \(stroke.title)" }
}
