import Foundation

enum Gender: String, Codable, CaseIterable, Identifiable {
    case male, female

    var id: String { rawValue }
    var title: String { self == .male ? "Мужской" : "Женский" }
}

enum Stroke: String, Codable, CaseIterable, Identifiable {
    case freestyle, backstroke, breaststroke, butterfly, medley

    var id: String { rawValue }
    var title: String {
        switch self {
        case .freestyle: return "Вольный стиль"
        case .backstroke: return "На спине"
        case .breaststroke: return "Брасс"
        case .butterfly: return "Баттерфляй"
        case .medley: return "Комплекс"
        }
    }
}

/// Длина бассейна. rawValue — метры.
enum Pool: Int, Codable, CaseIterable, Identifiable {
    case m25 = 25
    case m50 = 50

    var id: Int { rawValue }
    var title: String { "\(rawValue) м" }
}

/// Какие дистанции существуют для способа и бассейна.
enum EventCatalog {
    static func distances(stroke: Stroke, pool: Pool) -> [Int] {
        switch stroke {
        case .freestyle: return [50, 100, 200, 400, 800, 1500]
        case .backstroke, .breaststroke, .butterfly: return [50, 100, 200]
        // 100 м комплекс проводится только в бассейне 25 м
        case .medley: return pool == .m25 ? [100, 200, 400] : [200, 400]
        }
    }
}
