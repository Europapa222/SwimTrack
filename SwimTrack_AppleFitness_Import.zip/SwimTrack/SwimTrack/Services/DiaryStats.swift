import Foundation

/// Дисциплина = дистанция + способ + бассейн (время в 25 и 50 м сравнивать нельзя).
struct DisciplineKey: Hashable, Identifiable {
    let distance: Int
    let stroke: Stroke
    let pool: Pool

    var id: String { "\(pool.rawValue)-\(stroke.rawValue)-\(distance)" }
    var title: String { "\(distance) м · \(stroke.title)" }
}

extension SwimResult {
    var discipline: DisciplineKey {
        DisciplineKey(distance: distance, stroke: stroke, pool: pool)
    }
}

/// Все заплывы одной дисциплины и личный рекорд (лучшее время).
struct DisciplineSummary: Identifiable {
    let key: DisciplineKey
    /// По дате, старые первыми.
    let results: [SwimResult]
    let best: SwimResult

    var id: String { key.id }
    var count: Int { results.count }
}

struct ScoredResult: Identifiable {
    let result: SwimResult
    let points: Int
    var id: UUID { result.id }
}

enum DiaryStats {
    /// Дисциплины пользователя: сначала те, где больше заплывов.
    static func summaries(results: [SwimResult]) -> [DisciplineSummary] {
        let grouped = Dictionary(grouping: results, by: { $0.discipline })
        return grouped.compactMap { key, list -> DisciplineSummary? in
            guard let best = list.min(by: { $0.timeMs < $1.timeMs }) else { return nil }
            return DisciplineSummary(key: key, results: list.sorted { $0.date < $1.date }, best: best)
        }
        .sorted { a, b in a.count != b.count ? a.count > b.count : a.key.id < b.key.id }
    }

    /// Результаты с очками FINA (у дисциплин без базового времени очков нет).
    static func scored(_ results: [SwimResult]) -> [ScoredResult] {
        results.compactMap { r in
            FinaPoints.shared.points(for: r).map { ScoredResult(result: r, points: $0) }
        }
    }

    /// Нет ли в дисциплине результата быстрее этого.
    static func isPersonalBest(_ result: SwimResult, in all: [SwimResult]) -> Bool {
        !all.contains { $0.discipline == result.discipline && $0.timeMs < result.timeMs }
    }

    /// Доля пути до следующего разряда, 0...1 (для полосы прогресса).
    static func progress(timeMs: Int, normative: Normative, outcome: RankOutcome) -> Double {
        guard let next = outcome.next, let nextNorm = normative.ranks[next] else { return 1 }
        if let achieved = outcome.achieved, let achievedNorm = normative.ranks[achieved] {
            let span = Double(achievedNorm - nextNorm)
            guard span > 0 else { return 1 }
            return min(max(Double(achievedNorm - timeMs) / span, 0), 1)
        }
        // Ни один разряд пока не выполнен: сравниваем с нормативом самого низкого
        return min(max(Double(nextNorm) / Double(max(timeMs, 1)), 0), 1)
    }
}
