import Foundation

/// Очки World Aquatics (бывш. FINA): P = 1000 · (B / T)³,
/// где B — базовое время, T — время пловца (в секундах).
/// Базовые времена лежат в Resources/fina_base_times.json.
final class FinaPoints {
    static let shared = FinaPoints()

    private struct Entry: Codable {
        let gender: Gender
        let pool: Int
        let distance: Int
        let stroke: Stroke
        let seconds: Double
    }

    private var table: [String: Double] = [:]

    init(bundle: Bundle = .main) {
        guard let url = bundle.url(forResource: "fina_base_times", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let entries = try? JSONDecoder().decode([Entry].self, from: data) else {
            print("[FINA] Не найден справочник базовых времён")
            return
        }
        for e in entries {
            table[Self.key(gender: e.gender, pool: e.pool, distance: e.distance, stroke: e.stroke)] = e.seconds
        }
    }

    private static func key(gender: Gender, pool: Int, distance: Int, stroke: Stroke) -> String {
        "\(gender.rawValue)-\(pool)-\(stroke.rawValue)-\(distance)"
    }

    /// Очки за результат (nil — для дисциплины нет базового времени).
    /// Округление — вниз до целого.
    func points(for result: SwimResult) -> Int? {
        points(timeMs: result.timeMs, gender: result.gender, pool: result.pool,
               distance: result.distance, stroke: result.stroke)
    }

    func points(timeMs: Int, gender: Gender, pool: Pool, distance: Int, stroke: Stroke) -> Int? {
        guard timeMs > 0,
              let base = table[Self.key(gender: gender, pool: pool.rawValue, distance: distance, stroke: stroke)] else {
            return nil
        }
        let t = Double(timeMs) / 1000
        return Int(1000 * pow(base / t, 3))
    }
}
