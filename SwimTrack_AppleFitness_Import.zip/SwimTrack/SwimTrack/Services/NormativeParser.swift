import Foundation
import SwiftSoup

/// Результат разбора страницы.
struct ParseReport {
    var normatives: [Normative]
    /// Строки, которые не удалось разобрать или которые противоречат сами себе.
    var skippedRows: [String]
    /// Что парсер поправил или добавил сам: опечатки на сайте и строки, которых на сайте нет.
    var repairs: [String]
    /// Сколько из 4 таблиц (пол × бассейн) найдено.
    var tablesFound: Int
}

enum NormativeParserError: LocalizedError {
    case noTables
    case incomplete(found: Int)
    case incompleteNormatives(expected: Int, actual: Int)

    var errorDescription: String? {
        switch self {
        case .noTables: return "На странице Swim8 не найден полный набор нормативов"
        case .incomplete(let n): return "Найдено таблиц: \(n) из 4"
        case .incompleteNormatives(let expected, let actual):
            return "Получено нормативов: \(actual), ожидалось: \(expected)"
        }
    }
}

/// Парсер нормативов Swim8. Новый метод `parseSwim8` разбирает выбранную таблицу
/// по видимому тексту HTML. Старый `parse(text:)` оставлен для регрессионных тестов
/// прежнего источника и не используется приложением при обновлении нормативов.
enum NormativeParser {

    // MARK: - Swim8

    /// Swim8 отдаёт выбранную таблицу как набор подписанных строк:
    /// «50м Вольный стиль, Женщины» + девять значений нормативов.
    /// Отдельный запрос выполняется для каждой комбинации пола и длины бассейна.
    private static let swim8RowRegex = try! NSRegularExpression(
        pattern: "(\\d{2,4})\\s*м\\s+(вольный стиль|на спине|брасс|баттерфляй|комплексное плавание)\\s*,?\\s*(мужчины|женщины)",
        options: [.caseInsensitive]
    )
    private static let swim8TimeRegex = try! NSRegularExpression(
        pattern: "(?:\\d{1,2}:)?\\d{1,2}[.,]\\d{2}|-"
    )

    static func parseSwim8(html: String, pool: Pool, gender: Gender) throws -> ParseReport {
        let document = try SwiftSoup.parse(html)
        try document.select("script, style, noscript").remove()
        let text = try document.body()?.text() ?? ""
        let ns = text as NSString
        let matches = swim8RowRegex.matches(in: text, range: NSRange(location: 0, length: ns.length))
        var rows: [Normative] = []
        var skipped: [String] = []

        for (index, match) in matches.enumerated() {
            let rowGenderText = ns.substring(with: match.range(at: 3)).lowercased()
            let rowGender: Gender = rowGenderText.hasPrefix("м") ? .male : .female
            guard rowGender == gender,
                  let distance = Int(ns.substring(with: match.range(at: 1))) else { continue }

            let strokeName = ns.substring(with: match.range(at: 2)).lowercased()
            let stroke: Stroke
            if strokeName.contains("вольный") { stroke = .freestyle }
            else if strokeName.contains("спине") { stroke = .backstroke }
            else if strokeName.contains("брасс") { stroke = .breaststroke }
            else if strokeName.contains("баттерфляй") { stroke = .butterfly }
            else { stroke = .medley }

            let start = match.range.location + match.range.length
            let end = index + 1 < matches.count ? matches[index + 1].range.location : ns.length
            let tail = ns.substring(with: NSRange(location: start, length: max(0, end - start)))
            let tailNS = tail as NSString
            let valueMatches = swim8TimeRegex.matches(in: tail, range: NSRange(location: 0, length: tailNS.length))
            guard valueMatches.count >= Rank.columnOrder.count else {
                skipped.append("\(distance) м \(stroke.title), \(gender.title): найдено значений \(valueMatches.count) из 9")
                continue
            }

            var values: [Rank: Int] = [:]
            for (column, rank) in Rank.columnOrder.enumerated() {
                let token = tailNS.substring(with: valueMatches[column].range)
                if let milliseconds = TimeParser.parseMs(token) {
                    values[rank] = milliseconds
                }
            }

            let ordered = Rank.columnOrder.compactMap { values[$0] }
            guard !ordered.isEmpty, ordered == ordered.sorted() else {
                skipped.append("\(distance) м \(stroke.title), \(gender.title): нормативы нарушают порядок времени")
                continue
            }
            rows.append(Normative(distance: distance, stroke: stroke, pool: pool, gender: gender, ranks: values))
        }

        // На странице 50 м — 17 дисциплин, на странице 25 м — 18.
        // Не принимаем частичную страницу, чтобы не заменить полноценный кэш обрывком.
        let expectedCount = pool == .m25 ? 18 : 17
        guard rows.count == expectedCount else { throw NormativeParserError.noTables }
        return ParseReport(normatives: rows, skippedRows: skipped.sorted(), repairs: [], tablesFound: 1)
    }

    private struct SectionKey: Hashable {
        let gender: Gender
        let pool: Pool
    }

    /// Разобранная таблица: строки, пропущенные строки и сообщения о поправках.
    private struct Section {
        var rows: [Normative] = []
        var skipped: [String] = []
        var repairs: [String] = []
    }

    // MARK: - Известные опечатки на сайте

    /// Ошибочное значение на сайте и его исправление. Поправка применяется, только если
    /// на сайте всё ещё стоит именно `wrongMs`: когда там исправят опечатку, поправка
    /// просто перестанет срабатывать.
    private struct KnownFix {
        let gender: Gender
        let pool: Pool
        let stroke: Stroke
        let distance: Int
        let rank: Rank
        let wrongMs: Int
        let fixedMs: Int
        let reason: String
    }

    private static let knownFixes: [KnownFix] = [
        // Мужчины, 50 м, «на спине 50м»: III разряд записан 26,30 (быстрее II разряда 32,80).
        // Из таблицы бассейна 25 м (I 29,35 / II 32,05 / III 35,55 / I(ю) 41,55) видно, что
        // в 50-метровом бассейне все нормативы на 0,60–0,75 с медленнее: III = 35,55 + 0,75 = 36,30,
        // и 36,30 + 6,00 = 42,30 — ровно I(ю) этой же строки.
        KnownFix(gender: .male, pool: .m50, stroke: .backstroke, distance: 50, rank: .third,
                 wrongMs: 26_300, fixedMs: 36_300,
                 reason: "III разряд «26,30» исправлен на 36,30"),
        // Женщины, 25 м, «на спине 50м»: II разряд записан 46,55 (медленнее III разряда 40,55).
        // Бассейн 50 м той же дисциплины: I 32,30 / II 37,30 / III 41,30. Бассейн 25 м ровно
        // на 0,75 с быстрее: 31,55 / 36,55 / 40,55 — совпадает с I и III в этой строке.
        KnownFix(gender: .female, pool: .m25, stroke: .backstroke, distance: 50, rank: .second,
                 wrongMs: 46_550, fixedMs: 36_550,
                 reason: "II разряд «46,55» исправлен на 36,55"),
    ]

    // MARK: - Строки, которых на сайте нет

    /// Норматив, который существует, но в таблице на сайте отсутствует.
    /// Добавляется, только если в разобранной таблице такой дисциплины нет.
    private struct Supplement {
        let normative: Normative
        let note: String
    }

    private static let supplements: [Supplement] = [
        // Женщины, 50 м, «вольный стиль 50м»: на centrws.ru таблица начинается сразу со 100 м.
        // МС и КМС–III сверены по таблице ЕВСК на t-j.ru, КМС–III(ю) ещё и по open-pool.ru.
        // МСМК не добавлен: его значение пересматривается каждый год, надёжного значения,
        // согласованного с остальными строками таблицы, нет — для него будет «норматив не установлен».
        Supplement(
            normative: Normative(distance: 50, stroke: .freestyle, pool: .m50, gender: .female, ranks: [
                .ms: 26_500, .kms: 27_300, .first: 28_600, .second: 31_300, .third: 33_300,
                .firstYouth: 40_300, .secondYouth: 50_300, .thirdYouth: 59_800,
            ]),
            note: "строки нет на сайте, добавлена из других источников (без МСМК)"
        ),
    ]

    // MARK: - Регулярные выражения

    // Заголовок раздела. Совпадает и с навигацией сверху страницы
    // («Мужчины. Бассейн 50м»), поэтому из дубликатов берём раздел с наибольшим числом строк.
    private static let headingRegex = try! NSRegularExpression(
        pattern: "(МУЖЧИНЫ|ЖЕНЩИНЫ)\\s*[.,:]?\\s*БАССЕЙН\\s*(25|50)\\s*М",
        options: [.caseInsensitive]
    )

    // Название дисциплины: «вольный стиль 100м», «комплексное плавание 200м»,
    // а также эстафеты «4х100м вольный стиль*» (их находим, чтобы отрезать от соседних строк, но не сохраняем).
    private static let rowNameRegex = try! NSRegularExpression(
        pattern: "(?:\\d+\\s*[хxХX×]\\s*\\d+\\s*м\\s+(?:вольный стиль|комбинированная)|(?:вольный стиль|на спине|брасс|баттерфляй|комплексное плавание)\\s+\\d+\\s*м)\\*?",
        options: [.caseInsensitive]
    )

    private static let distanceRegex = try! NSRegularExpression(pattern: "(\\d+)\\s*м", options: [.caseInsensitive])

    /// Ячейка из одних цифр: «30».
    private static let bareNumberRegex = try! NSRegularExpression(pattern: "^\\d{1,2}$")
    /// Склеенные ячейки «00,31,65» (на деле это «00» и «31,65»).
    private static let gluedRegex = try! NSRegularExpression(pattern: "^(\\d{2}),(\\d{1,2}[,.]\\d{2})$")
    /// Минуты через запятую: «3,56,00» (на деле «3.56,00»).
    private static let commaMinutesRegex = try! NSRegularExpression(pattern: "^\\d{1,2},\\d{2},\\d{2}$")

    // MARK: - Разбор страницы

    /// Разбор HTML страницы.
    static func parse(html: String) throws -> ParseReport {
        let doc = try SwiftSoup.parse(html)
        try doc.select("script, style, noscript").remove()
        let text = try doc.body()?.text() ?? ""
        return try parse(text: text)
    }

    /// Разбор уже очищенного текста (удобно для тестов).
    static func parse(text: String) throws -> ParseReport {
        let ns = text as NSString
        let headings = headingRegex.matches(in: text, range: NSRange(location: 0, length: ns.length))

        var best: [SectionKey: Section] = [:]

        for (i, h) in headings.enumerated() {
            let genderWord = ns.substring(with: h.range(at: 1)).lowercased()
            let gender: Gender = genderWord.hasPrefix("м") ? .male : .female
            guard let pool = Pool(rawValue: Int(ns.substring(with: h.range(at: 2))) ?? 0) else { continue }

            // Тело раздела — от конца заголовка до начала следующего заголовка
            let start = h.range.location + h.range.length
            let end = i + 1 < headings.count ? headings[i + 1].range.location : ns.length
            let body = ns.substring(with: NSRange(location: start, length: end - start))

            let section = parseSection(body, gender: gender, pool: pool)
            let key = SectionKey(gender: gender, pool: pool)
            if section.rows.count > (best[key]?.rows.count ?? 0) {
                best[key] = section
            }
        }

        let tables = best.filter { !$0.value.rows.isEmpty }
        if tables.isEmpty { throw NormativeParserError.noTables }
        // Неполный набор (например, сайт перестроили) не принимаем, чтобы не затереть хороший кэш
        if tables.count < 4 { throw NormativeParserError.incomplete(found: tables.count) }

        let all = tables.values.flatMap { $0.rows }
        let skipped = tables.values.flatMap { $0.skipped }
        let repairs = tables.values.flatMap { $0.repairs }
        return ParseReport(normatives: all, skippedRows: skipped.sorted(),
                           repairs: repairs.sorted(), tablesFound: tables.count)
    }

    // MARK: - Раздел (одна таблица)

    private static func parseSection(_ body: String, gender: Gender, pool: Pool) -> Section {
        let ns = body as NSString
        let names = rowNameRegex.matches(in: body, range: NSRange(location: 0, length: ns.length))
        var section = Section()
        let label = "\(gender == .male ? "М" : "Ж") \(pool.rawValue) м"

        for (i, m) in names.enumerated() {
            let name = ns.substring(with: m.range)
            // Эстафеты в MVP не нужны
            guard let (distance, stroke) = classify(name) else { continue }

            // Текст между этим названием и следующим — ячейки со временем
            let cellsStart = m.range.location + m.range.length
            let cellsEnd = i + 1 < names.count ? names[i + 1].range.location : ns.length
            var chunk = ns.substring(with: NSRange(location: cellsStart, length: cellsEnd - cellsStart))
            // Сноска «*только для спортсмена, стартующего первым» — не данные
            if let star = chunk.firstIndex(of: "*") { chunk = String(chunk[..<star]) }

            // 1. Ячейки, с лечением перепутанных разделителей
            let split = splitCells(chunk)
            let (cells, cellNotes) = repairCells(split)
            let times = cells.map { TimeParser.parseMs($0) }

            // Ровно 9 разрядов и все значения распознаны
            guard cells.count == Rank.columnOrder.count, times.allSatisfy({ $0 != nil }) else {
                section.skipped.append("\(label) · \(name): не удалось разобрать «\(split.joined(separator: "; "))»")
                continue
            }
            var values = times.compactMap { $0 }
            var notes = cellNotes

            // 2. Известные опечатки в значениях
            for fix in knownFixes
            where fix.gender == gender && fix.pool == pool && fix.stroke == stroke && fix.distance == distance {
                if let index = Rank.columnOrder.firstIndex(of: fix.rank), values[index] == fix.wrongMs {
                    values[index] = fix.fixedMs
                    notes.append(fix.reason)
                }
            }

            // 3. Проверка здравого смысла: чем ниже разряд, тем время больше.
            // Неисправленные опечатки здесь отсекаются: такую строку не берём вообще,
            // чтобы не определять разряд по заведомо неверному нормативу.
            guard zip(values, values.dropFirst()).allSatisfy({ $0 < $1 }) else {
                section.skipped.append("\(label) · \(name): нарушен порядок времён «\(split.joined(separator: "; "))»")
                continue
            }

            var ranks: [Rank: Int] = [:]
            for (rank, value) in zip(Rank.columnOrder, values) { ranks[rank] = value }
            section.rows.append(Normative(distance: distance, stroke: stroke, pool: pool, gender: gender, ranks: ranks))
            if !notes.isEmpty {
                section.repairs.append("\(label) · \(name): \(notes.joined(separator: "; "))")
            }
        }

        // 4. Строки, которых на сайте нет. Только для настоящей таблицы: в навигации
        // страницы заголовки встречаются тоже, но строк под ними нет.
        if !section.rows.isEmpty {
            for supplement in supplements where supplement.normative.gender == gender && supplement.normative.pool == pool {
                let key = supplement.normative.key
                guard !section.rows.contains(where: { $0.key == key }) else { continue }
                section.rows.append(supplement.normative)
                section.repairs.append("\(label) · \(supplement.normative.distance) м \(supplement.normative.stroke.title.lowercased()): \(supplement.note)")
            }
        }
        return section
    }

    /// Ячейки: на Tilda разделены «;», в обычной таблице — пробелами между <td>.
    private static func splitCells(_ chunk: String) -> [String] {
        let parts: [Substring]
        if chunk.contains(";") {
            parts = chunk.split(separator: ";", omittingEmptySubsequences: true)
        } else {
            parts = chunk.split(whereSeparator: { $0.isWhitespace })
        }
        return parts
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    /// Лечит ячейки, испорченные перепутанными разделителями.
    /// «30;00,31,65» на сайте — это «30,00;31,65»: после целого числа идёт склейка
    /// «секунды,время». Склейку разделяем и возвращаем ячейки в порядке таблицы.
    /// Дальше строка всё равно проходит проверку на 9 значений и порядок времён.
    private static func repairCells(_ cells: [String]) -> (cells: [String], notes: [String]) {
        var result: [String] = []
        var notes: [String] = []
        var i = 0
        while i < cells.count {
            let cell = cells[i]
            if i + 1 < cells.count, matches(bareNumberRegex, cell), let glued = groups(gluedRegex, cells[i + 1]) {
                let fixed = "\(cell),\(glued[0])"
                result.append(fixed)
                result.append(glued[1])
                notes.append("ячейки «\(cell); \(cells[i + 1])» прочитаны как «\(fixed); \(glued[1])»")
                i += 2
                continue
            }
            if matches(commaMinutesRegex, cell) {
                notes.append("«\(cell)» прочитано как время с минутами")
            }
            result.append(cell)
            i += 1
        }
        return (result, notes)
    }

    private static func matches(_ regex: NSRegularExpression, _ s: String) -> Bool {
        regex.firstMatch(in: s, range: NSRange(location: 0, length: (s as NSString).length)) != nil
    }

    /// Захваченные группы регулярки (nil — не совпало).
    private static func groups(_ regex: NSRegularExpression, _ s: String) -> [String]? {
        let ns = s as NSString
        guard let m = regex.firstMatch(in: s, range: NSRange(location: 0, length: ns.length)) else { return nil }
        return (1..<m.numberOfRanges).map { ns.substring(with: m.range(at: $0)) }
    }

    /// «вольный стиль 100м» → (100, .freestyle). Эстафеты («4х100м …») → nil.
    private static func classify(_ name: String) -> (Int, Stroke)? {
        let lower = name.lowercased()
        if let first = lower.first, first.isNumber { return nil }
        let ns = lower as NSString
        guard let m = distanceRegex.firstMatch(in: lower, range: NSRange(location: 0, length: ns.length)),
              let distance = Int(ns.substring(with: m.range(at: 1))) else { return nil }

        let stroke: Stroke
        if lower.contains("вольный") { stroke = .freestyle }
        else if lower.contains("на спине") { stroke = .backstroke }
        else if lower.contains("брасс") { stroke = .breaststroke }
        else if lower.contains("баттерфляй") { stroke = .butterfly }
        else if lower.contains("комплекс") { stroke = .medley }
        else { return nil }
        return (distance, stroke)
    }
}
