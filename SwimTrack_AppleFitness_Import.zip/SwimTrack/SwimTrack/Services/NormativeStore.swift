import Foundation
import CryptoKit

/// Хранит нормативы: кэш в UserDefaults + фоновое обновление с Swim8.
@MainActor
final class NormativeStore: ObservableObject {

    nonisolated private static func sourceURL(pool: Pool, gender: Gender) -> URL {
        var components = URLComponents(string: "https://swim8.ru/standards")!
        var query = [URLQueryItem]()
        // Swim8 использует специальный параметр course=SCM для 25 м.
        // Страница 50 м является маршрутом по умолчанию, поэтому course=LCM не передаём.
        if pool == .m25 { query.append(URLQueryItem(name: "course", value: "SCM")) }
        query.append(URLQueryItem(name: "gender", value: gender == .female ? "F" : "M"))
        components.queryItems = query
        return components.url!
    }

    @Published private(set) var normatives: [Normative] = []
    /// Когда данные последний раз успешно получены с сайта.
    @Published private(set) var dataDate: Date?
    /// Строки, которые не удалось разобрать.
    @Published private(set) var skippedRows: [String] = []
    /// Опечатки и пропуски на сайте, которые парсер поправил сам.
    @Published private(set) var repairs: [String] = []
    @Published private(set) var lastError: String?
    @Published private(set) var isRefreshing = false
    /// Текст всплывающего сообщения («Нормативы обновлены»).
    @Published var toast: String?

    private struct Cache: Codable {
        var normatives: [Normative]
        var hash: String
        var savedAt: Date
        var skipped: [String]
        var repairs: [String]
    }

    private enum FetchError: LocalizedError {
        case badStatus(Int)
        case decoding
        var errorDescription: String? {
            switch self {
            case .badStatus(let code): return "Сервер ответил кодом \(code)"
            case .decoding: return "Не удалось прочитать страницу"
            }
        }
    }

    private let defaults: UserDefaults
    // v3: источник изменён на Swim8, старый кэш centrws не смешиваем с новыми данными.
    private let cacheKey = "swimtrack.normatives.cache.v3"
    private let lastCheckKey = "swimtrack.normatives.lastCheck.v3"
    private var currentHash: String?
    private var index: [String: Normative] = [:]

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        loadCache()
    }

    // MARK: - Доступ к данным

    func normative(distance: Int, stroke: Stroke, pool: Pool, gender: Gender) -> Normative? {
        index[Normative.key(distance: distance, stroke: stroke, pool: pool, gender: gender)]
    }

    /// Строка статуса для интерфейса.
    var statusText: String {
        guard let date = dataDate else { return "Нормативы ещё не загружены" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "dd.MM.yyyy"
        return "Данные от \(f.string(from: date))"
    }

    /// Предупреждение, если последняя попытка обновления не удалась.
    var staleNotice: String? {
        guard lastError != nil else { return nil }
        return normatives.isEmpty ? "Нет связи с источником, нормативы не загружены" : "Нет связи с источником. \(statusText)"
    }

    // MARK: - Обновление

    /// Проверка раз в сутки (и сразу, если кэша ещё нет).
    func refreshIfNeeded() async {
        let last = defaults.object(forKey: lastCheckKey) as? Date
        if normatives.isEmpty || last == nil || Date().timeIntervalSince(last!) > 24 * 3600 {
            await refresh(manual: false)
        }
    }

    /// Загрузка и разбор страницы. Любая ошибка оставляет приложение на кэше.
    func refresh(manual: Bool) async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        do {
            // Загружаем четыре независимые страницы: два пола × два типа бассейна.
            // Это соответствует параметрам Swim8 course=SCM/LCM и gender=F/M.
            let reports = try await withThrowingTaskGroup(of: ParseReport.self) { group in
                for gender in Gender.allCases {
                    for pool in Pool.allCases {
                        group.addTask {
                            var request = URLRequest(url: Self.sourceURL(pool: pool, gender: gender), timeoutInterval: 25)
                            request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)", forHTTPHeaderField: "User-Agent")
                            request.setValue("text/html,application/xhtml+xml", forHTTPHeaderField: "Accept")
                            let (data, response) = try await URLSession.shared.data(for: request)
                            if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
                                throw FetchError.badStatus(http.statusCode)
                            }
                            guard let html = String(data: data, encoding: .utf8) else { throw FetchError.decoding }
                            return try await Task.detached(priority: .utility) {
                                try NormativeParser.parseSwim8(html: html, pool: pool, gender: gender)
                            }.value
                        }
                    }
                }
                var collected: [ParseReport] = []
                for try await report in group { collected.append(report) }
                return collected
            }
            let report = ParseReport(
                normatives: reports.flatMap(\.normatives),
                skippedRows: reports.flatMap(\.skippedRows).sorted(),
                repairs: reports.flatMap(\.repairs).sorted(),
                tablesFound: reports.reduce(0) { $0 + $1.tablesFound }
            )
            guard report.tablesFound == 4 else {
                throw NormativeParserError.incomplete(found: report.tablesFound)
            }
            guard report.normatives.count == 70 else {
                throw NormativeParserError.incompleteNormatives(expected: 70, actual: report.normatives.count)
            }

            let newHash = Self.hash(of: report.normatives)
            let changed = newHash != currentHash
            apply(normatives: report.normatives, skipped: report.skippedRows, repairs: report.repairs,
                  hash: newHash, date: Date())
            defaults.set(Date(), forKey: lastCheckKey)
            lastError = nil

            if changed {
                toast = "Нормативы обновлены"
            } else if manual {
                toast = "Нормативы актуальны"
            }
        } catch {
            // Не падаем: остаёмся на кэше, кэш не перезаписываем
            lastError = error.localizedDescription
            if manual { toast = "Не удалось обновить. \(statusText)" }
            print("[Normatives] Ошибка обновления: \(error.localizedDescription)")
        }
    }

    // MARK: - Кэш

    private func loadCache() {
        guard let data = defaults.data(forKey: cacheKey),
              let cache = try? JSONDecoder().decode(Cache.self, from: data),
              !cache.normatives.isEmpty else { return }
        setState(normatives: cache.normatives, skipped: cache.skipped, repairs: cache.repairs,
                 hash: cache.hash, date: cache.savedAt)
    }

    private func apply(normatives: [Normative], skipped: [String], repairs: [String], hash: String, date: Date) {
        setState(normatives: normatives, skipped: skipped, repairs: repairs, hash: hash, date: date)
        let cache = Cache(normatives: normatives, hash: hash, savedAt: date, skipped: skipped, repairs: repairs)
        if let data = try? JSONEncoder().encode(cache) {
            defaults.set(data, forKey: cacheKey)
        }
    }

    private func setState(normatives: [Normative], skipped: [String], repairs: [String], hash: String, date: Date) {
        self.normatives = normatives
        self.skippedRows = skipped
        self.repairs = repairs
        self.currentHash = hash
        self.dataDate = date
        self.index = Dictionary(normatives.map { ($0.key, $0) }, uniquingKeysWith: { first, _ in first })
        logCounts()
    }

    /// Сколько дисциплин распознано в каждой из 4 таблиц (вывод в консоль Xcode).
    private func logCounts() {
        for gender in Gender.allCases {
            for pool in Pool.allCases {
                let n = normatives.filter { $0.gender == gender && $0.pool == pool }.count
                print("[Normatives] \(gender.rawValue), бассейн \(pool.rawValue) м: \(n) дисциплин")
            }
        }
        print("[Normatives] Всего дисциплин: \(normatives.count), пропущено строк: \(skippedRows.count), поправок: \(repairs.count)")
    }

    /// Хэш содержимого: если он не изменился, нормативы на сайте прежние.
    static func hash(of normatives: [Normative]) -> String {
        let lines = normatives.map { n -> String in
            let values = Rank.allCases.map { n.ranks[$0].map(String.init) ?? "-" }.joined(separator: ",")
            return "\(n.key):\(values)"
        }.sorted().joined(separator: "\n")
        let digest = SHA256.hash(data: Data(lines.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
