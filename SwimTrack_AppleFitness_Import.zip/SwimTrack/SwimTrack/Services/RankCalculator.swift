import Foundation

/// Итог сравнения времени с нормативами.
struct RankOutcome: Equatable {
    /// Выполненный разряд (nil — ни один норматив не выполнен).
    let achieved: Rank?
    /// Ближайший более высокий разряд, который можно получить по возрасту.
    let next: Rank?
    /// Сколько миллисекунд не хватает до `next`.
    let gapMs: Int?
    /// Норматив более высокого звания выполнен, но возраст пока не позволяет его присвоить.
    let blockedByAge: Rank?

    /// «до I разряда не хватает 0,05 сек»
    var gapText: String? {
        guard let next, let gapMs else { return nil }
        return "до \(next.genitive) не хватает \(TimeParser.secondsText(ms: gapMs)) сек"
    }
}

enum RankCalculator {

    /// Определяет разряд по времени.
    ///
    /// Время меньше = лучше. Идём от МСМК к III(ю) и берём первый разряд,
    /// у которого `timeMs <= норматива`.
    /// - Parameters:
    ///   - age: возраст спортсмена; nil — возраст не известен, ограничения не применяются.
    static func evaluate(timeMs: Int, normative: Normative, age: Int?) -> RankOutcome {
        // Разряды по убыванию уровня, только те, для которых норматив есть
        // (в источнике бывают пропуски — «норматив не установлен»).
        let available = Rank.allCases.filter { normative.ranks[$0] != nil }

        func isAllowed(_ rank: Rank) -> Bool {
            guard let age, let minimum = rank.minimumAge else { return true }
            return age >= minimum
        }

        // 1. Первый выполненный разряд среди тех, что разрешены по возрасту
        let eligible = available.filter(isAllowed)
        let achievedIndex = eligible.firstIndex { timeMs <= normative.ranks[$0]! }
        let achieved = achievedIndex.map { eligible[$0] }

        // 2. До какого разряда не хватает: ближайший выше достигнутого
        //    (если ничего не выполнено — самый низкий из доступных).
        var next: Rank?
        var gap: Int?
        if let idx = achievedIndex {
            if idx > 0 { next = eligible[idx - 1] }
        } else {
            next = eligible.last
        }
        if let next, let norm = normative.ranks[next] {
            gap = timeMs - norm
        }

        // 3. Выполнено ли «слишком взрослое» звание (КМС/МС/МСМК) при малом возрасте
        var blocked: Rank?
        if let first = available.first(where: { !isAllowed($0) && timeMs <= normative.ranks[$0]! }) {
            // Показываем только если оно выше фактически присвоимого разряда
            let achievedLevel = achieved.flatMap { Rank.allCases.firstIndex(of: $0) } ?? Int.max
            if let level = Rank.allCases.firstIndex(of: first), level < achievedLevel { blocked = first }
        }

        return RankOutcome(achieved: achieved, next: next, gapMs: gap, blockedByAge: blocked)
    }
}
