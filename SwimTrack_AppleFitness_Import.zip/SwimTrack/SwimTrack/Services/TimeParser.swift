import Foundation

/// Разбор и форматирование времени заплыва.
enum TimeParser {
    // Допускаем «1:03,84», «1.04,60» (так записано на centrws.ru) и «27,85».
    // Минуты от секунд могут отделяться точкой, двоеточием и запятой: на сайте
    // встречается опечатка «3,56,00» вместо «3.56,00», её читаем как 3:56,00.
    // Группы: 1 — минуты (необязательно), 2 — секунды, 3 — сотые.
    private static let regex = try! NSRegularExpression(
        pattern: "^(?:(\\d{1,2})[.:,])?(\\d{1,2})[,.](\\d{2})$"
    )

    /// Время из текста в миллисекунды. nil — если формат не распознан.
    static func parseMs(_ raw: String) -> Int? {
        let s = raw
            .replacingOccurrences(of: "\u{00A0}", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let ns = s as NSString
        guard let m = regex.firstMatch(in: s, range: NSRange(location: 0, length: ns.length)) else {
            return nil
        }
        let minutes = m.range(at: 1).location == NSNotFound ? 0 : Int(ns.substring(with: m.range(at: 1))) ?? 0
        guard let seconds = Int(ns.substring(with: m.range(at: 2))),
              let hundredths = Int(ns.substring(with: m.range(at: 3))) else { return nil }
        // Секунды не могут быть ≥ 60, если указаны минуты
        if minutes > 0 && seconds >= 60 { return nil }
        let total = minutes * 60_000 + seconds * 1000 + hundredths * 10
        return total > 0 ? total : nil
    }

    /// 63840 → «1:03,84», 27850 → «27,85»
    static func format(ms: Int) -> String {
        let hundredths = Int((Double(ms) / 10).rounded())
        let minutes = hundredths / 6000
        let seconds = (hundredths / 100) % 60
        let rest = hundredths % 100
        if minutes > 0 {
            return String(format: "%d:%02d,%02d", minutes, seconds, rest)
        }
        return String(format: "%d,%02d", seconds, rest)
    }

    /// 50 → «0,05» (разница в секундах для фраз «не хватает 0,05 сек»)
    static func secondsText(ms: Int) -> String {
        String(format: "%.2f", Double(ms) / 1000).replacingOccurrences(of: ".", with: ",")
    }
}
