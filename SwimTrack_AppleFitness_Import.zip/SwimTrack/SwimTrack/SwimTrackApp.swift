import SwiftUI

@main
@MainActor
struct SwimTrackApp: App {
    @StateObject private var normatives = NormativeStore()
    @StateObject private var results = ResultsStore()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(normatives)
                .environmentObject(results)
                .environment(\.locale, Locale(identifier: "ru_RU"))
                // Показываем кэш сразу, а обновление идёт фоном
                .task { await normatives.refreshIfNeeded() }
                .onChange(of: scenePhase) { phase in
                    if phase == .active {
                        Task { await normatives.refreshIfNeeded() }
                    }
                }
        }
    }
}
