import SwiftUI

/// Возраст спрашиваем один раз: от него зависит, можно ли показать КМС / МС / МСМК.
struct AgeSheet: View {
    @State private var age = 14
    let onConfirm: (Int) -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Возраст", selection: $age) {
                        ForEach(6...90, id: \.self) { Text("\($0)").tag($0) }
                    }
                    .pickerStyle(.wheel)
                } footer: {
                    Text("Звание КМС присваивается с 10 лет, МС — с 12, МСМК — с 14. Возраст нужен, чтобы не показывать звания, которые ещё нельзя получить. Спросим один раз.")
                }
            }
            .navigationTitle("Ваш возраст")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Продолжить") { onConfirm(age) }
                }
            }
        }
        .presentationDetents([.medium])
    }
}
