import SwiftUI
import Charts

// Карточки вкладки «Дневник». Здесь только отображение: все данные приходят готовыми
// значениями, поэтому карточки не зависят от хранилищ.

// MARK: - Строка списка без системного оформления

struct DiaryRowStyle: ViewModifier {
    var top: CGFloat
    var bottom: CGFloat
    var horizontal: CGFloat

    func body(content: Content) -> some View {
        content
            .listRowSeparator(.hidden)
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: top, leading: horizontal, bottom: bottom, trailing: horizontal))
    }
}

extension View {
    func diaryRow(top: CGFloat = 8, bottom: CGFloat = 8, horizontal: CGFloat = 16) -> some View {
        modifier(DiaryRowStyle(top: top, bottom: bottom, horizontal: horizontal))
    }
}

// MARK: - Главная карточка

struct HeroCard: View {
    let scored: ScoredResult
    let rank: Rank?

    var body: some View {
        let r = scored.result
        ZStack(alignment: .bottom) {
            Theme.heroGradient
            WaveLayer().frame(height: 110)

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Image(systemName: "star.fill")
                    Text("Лучший результат по очкам")
                }
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .opacity(0.9)

                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    AnimatedNumber(target: scored.points)
                        .font(.system(size: 68, weight: .heavy, design: .rounded))
                    Text("очков FINA")
                        .font(.system(.headline, design: .rounded))
                        .opacity(0.9)
                }

                Spacer(minLength: 14)

                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(TimeParser.format(ms: r.timeMs))
                            .font(.system(size: 26, weight: .bold, design: .rounded))
                            .monospacedDigit()
                        Text("\(r.eventTitle) · \(r.pool.rawValue) м")
                            .font(.footnote)
                            .opacity(0.9)
                    }
                    Spacer()
                    RankBadge(rank: rank)
                }
            }
            .foregroundStyle(.white)
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: 210)
        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.7), Color.white.opacity(0.1)],
                                             startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.2)
        }
        .shadow(color: Theme.stand.opacity(0.16), radius: 22, y: 12)
    }
}

struct EmptyDiaryCard: View {
    let onAdd: () -> Void

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "figure.pool.swim")
                .font(.system(size: 54))
                .foregroundStyle(Theme.accentGradient)
            Text("Здесь будет твой дневник")
                .font(.system(.title2, design: .rounded).weight(.bold))
            Text("Добавь первый заплыв: посчитаем очки FINA, определим разряд и нарисуем график прогресса.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button(action: onAdd) {
                Label("Добавить заплыв", systemImage: "plus")
                    .font(.system(.headline, design: .rounded))
                    .padding(.horizontal, 22)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(Theme.accentGradient, in: Capsule())
                    .shadow(color: Theme.accent.opacity(0.4), radius: 12, y: 6)
            }
            .buttonStyle(PressableStyle())
        }
        .padding(28)
        .frame(maxWidth: .infinity)
        .glassCard(radius: 32)
        .padding(.top, 40)
    }
}

// MARK: - Статистика

struct StatsRow: View {
    let total: Int
    let disciplines: Int
    let topRank: Rank?

    var body: some View {
        HStack(spacing: 10) {
            tile(icon: "figure.pool.swim", value: "\(total)", label: "заплывов", color: Theme.stand)
            tile(icon: "flag.checkered", value: "\(disciplines)", label: "дисциплин", color: Theme.move)
            tile(icon: "rosette", value: topRank?.rawValue ?? "—", label: "высший разряд",
                 color: topRank?.tint ?? Theme.exercise)
        }
    }

    private func tile(icon: String, value: String, label: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(color)
            Text(value)
                .font(.system(.title2, design: .rounded).weight(.bold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .glassCard(radius: 22, tint: color)
    }
}

// MARK: - Карусель личных рекордов

struct DisciplineCardModel: Identifiable {
    let summary: DisciplineSummary
    let rank: Rank?
    let points: Int?
    var id: String { summary.id }
}

struct DisciplineCarousel: View {
    let models: [DisciplineCardModel]
    let selected: DisciplineKey?
    let onSelect: (DisciplineKey) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionTitle(title: "Личные рекорды", subtitle: "Нажми на дисциплину, чтобы увидеть прогресс")
                .padding(.horizontal, 20)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(models) { model in
                        card(model)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            }
        }
    }

    private func card(_ model: DisciplineCardModel) -> some View {
        let key = model.summary.key
        let isSelected = key == selected
        let tint = key.stroke.tint
        return Button {
            Haptics.tap()
            onSelect(key)
        } label: {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline, spacing: 3) {
                    Text("\(key.distance)")
                        .font(.system(size: 34, weight: .heavy, design: .rounded))
                    Text("м")
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    RankBadge(rank: model.rank, compact: true)
                }
                Text(key.stroke.title)
                    .font(.subheadline.weight(.semibold))
                Text(TimeParser.format(ms: model.summary.best.timeMs))
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .monospacedDigit()
                    .foregroundStyle(tint)
                HStack {
                    Pill(text: "бассейн \(key.pool.rawValue) м", tint: tint)
                    Spacer()
                    if let points = model.points {
                        Text("\(points) оч.")
                            .font(.caption.weight(.semibold))
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .padding(14)
            .frame(width: 210, alignment: .leading)
            .glassCard(radius: 24, tint: isSelected ? tint : nil)
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .strokeBorder(tint, lineWidth: isSelected ? 2 : 0)
            }
            .scaleEffect(isSelected ? 1 : 0.96)
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - График прогресса

struct ProgressCard: View {
    let title: String
    let tint: Color
    let scored: [ScoredResult]

    @State private var selectedID: UUID?

    private var best: ScoredResult? { scored.max { $0.points < $1.points } }
    private var shown: ScoredResult? { scored.first { $0.id == selectedID } ?? scored.last }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            header
            if scored.isEmpty {
                Text("Для этой дисциплины нет базового времени FINA, график очков недоступен.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 30)
            } else {
                chart
                if scored.count < 2 {
                    Text("Добавь ещё один результат в этой дисциплине, чтобы увидеть динамику.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else {
                    Text("Нажми на график, чтобы выбрать заплыв")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(18)
        .glassCard(radius: 28)
        .onChange(of: title) { _ in selectedID = nil }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Прогресс очков")
                    .font(.system(.footnote, design: .rounded).weight(.semibold))
                    .foregroundStyle(.secondary)
                Text(title)
                    .font(.system(.headline, design: .rounded))
                    .lineLimit(2)
            }
            Spacer()
            if let shown {
                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(shown.points)")
                        .font(.system(size: 30, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(tint)
                        .contentTransition(.numericText())
                    Text("\(TimeParser.format(ms: shown.result.timeMs)) · \(shown.result.date.formatted(.dateTime.day().month(.abbreviated)))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .animation(.spring(response: 0.35, dampingFraction: 0.8), value: shown.id)
            }
        }
    }

    private var chart: some View {
        Chart {
            ForEach(scored) { item in
                AreaMark(x: .value("Дата", item.result.date), y: .value("Очки", item.points))
                    .interpolationMethod(.monotone)
                    .foregroundStyle(LinearGradient(colors: [tint.opacity(0.35), tint.opacity(0.02)],
                                                    startPoint: .top, endPoint: .bottom))
                LineMark(x: .value("Дата", item.result.date), y: .value("Очки", item.points))
                    .interpolationMethod(.monotone)
                    .lineStyle(StrokeStyle(lineWidth: 3.5, lineCap: .round, lineJoin: .round))
                    .foregroundStyle(tint)
                PointMark(x: .value("Дата", item.result.date), y: .value("Очки", item.points))
                    .symbolSize(46)
                    .foregroundStyle(tint)
            }
            if let selected = scored.first(where: { $0.id == selectedID }) {
                RuleMark(x: .value("Дата", selected.result.date))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 4]))
                    .foregroundStyle(Color.secondary.opacity(0.5))
                PointMark(x: .value("Дата", selected.result.date), y: .value("Очки", selected.points))
                    .symbolSize(170)
                    .foregroundStyle(Color.white)
                PointMark(x: .value("Дата", selected.result.date), y: .value("Очки", selected.points))
                    .symbolSize(90)
                    .foregroundStyle(tint)
            }
            // Личный рекорд — оранжевая точка со звездой
            if let best {
                PointMark(x: .value("Дата", best.result.date), y: .value("Очки", best.points))
                    .symbolSize(130)
                    .foregroundStyle(Color.orange)
                    .annotation(position: .top, spacing: 4) {
                        Image(systemName: "star.fill")
                            .font(.caption)
                            .foregroundStyle(Color.orange)
                    }
            }
        }
        .chartYScale(domain: .automatic(includesZero: false))
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 4)) { _ in
                AxisValueLabel(format: .dateTime.day().month(.abbreviated))
            }
        }
        .chartOverlay { proxy in
            GeometryReader { geo in
                Rectangle()
                    .fill(Color.clear)
                    .contentShape(Rectangle())
                    .gesture(
                        SpatialTapGesture().onEnded { value in
                            pick(at: value.location, proxy: proxy, geo: geo)
                        }
                    )
            }
        }
        .frame(height: 220)
    }

    /// Выбор ближайшего к нажатию заплыва.
    private func pick(at location: CGPoint, proxy: ChartProxy, geo: GeometryProxy) {
        let origin = geo[proxy.plotAreaFrame].origin
        guard let date = proxy.value(atX: location.x - origin.x, as: Date.self) else { return }
        let nearest = scored.min {
            abs($0.result.date.timeIntervalSince(date)) < abs($1.result.date.timeIntervalSince(date))
        }
        if let nearest {
            Haptics.tap()
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { selectedID = nearest.id }
        }
    }
}

// MARK: - Цель

struct GoalCard: View {
    let tint: Color
    let current: Rank?
    let next: Rank?
    let gapText: String?
    let progress: Double
    let blocked: Rank?
    let noNormative: Bool

    @State private var shownProgress: Double = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(next?.gradient ?? Theme.goldGradient)
                    Image(systemName: icon)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white)
                }
                .frame(width: 44, height: 44)

                VStack(alignment: .leading, spacing: 2) {
                    Text(noNormative ? "Норматив не установлен" : (next == nil ? "Высшая цель достигнута" : "Следующая цель"))
                        .font(.system(.footnote, design: .rounded).weight(.semibold))
                        .foregroundStyle(.secondary)
                    if let next {
                        Text(next.rawValue)
                            .font(.system(.title2, design: .rounded).weight(.heavy))
                    } else if !noNormative {
                        Text("Максимальный разряд")
                            .font(.system(.title3, design: .rounded).weight(.bold))
                    }
                }
                Spacer()
            }

            if !noNormative {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.secondary.opacity(0.18))
                        Capsule()
                            .fill(next?.gradient ?? Theme.goldGradient)
                            .frame(width: max(14, geo.size.width * shownProgress))
                    }
                }
                .frame(height: 12)

                if let gapText {
                    Text(gapText.prefix(1).uppercased() + gapText.dropFirst())
                        .font(.subheadline.weight(.medium))
                }
            } else {
                Text("Для этой дисциплины в таблице нормативов нет данных или строка на сайте повреждена.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            if let blocked {
                Label("Норматив \(blocked.rawValue) выполнен, но по возрасту звание пока не присваивается",
                      systemImage: "lock.fill")
                    .font(.caption)
                    .foregroundStyle(Color.orange)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28, tint: next?.tint ?? tint)
        .onAppear { animate() }
        .onChange(of: progress) { _ in animate() }
    }

    private var icon: String {
        noNormative ? "questionmark" : (next == nil ? "checkmark.seal.fill" : "flag.checkered")
    }

    private func animate() {
        withAnimation(.spring(response: 0.9, dampingFraction: 0.8)) { shownProgress = progress }
    }
}

// MARK: - История

struct ResultRow: View {
    let result: SwimResult
    let rank: Rank?
    let points: Int?
    let isBest: Bool
    let showMonth: Bool
    let onTap: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if showMonth {
                Text(monthTitle(result.date))
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .foregroundStyle(.secondary)
                    .padding(.top, 10)
                    .padding(.leading, 4)
            }
            Button(action: onTap) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14, style: .continuous).fill(result.stroke.gradient)
                        VStack(spacing: -2) {
                            Text("\(result.distance)")
                                .font(.system(size: 17, weight: .heavy, design: .rounded))
                            Text("м")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .opacity(0.85)
                        }
                        .foregroundStyle(.white)
                    }
                    .frame(width: 48, height: 48)

                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 6) {
                            Text(TimeParser.format(ms: result.timeMs))
                                .font(.system(.title3, design: .rounded).weight(.bold))
                                .monospacedDigit()
                            if isBest {
                                Image(systemName: "star.fill")
                                    .font(.caption)
                                    .foregroundStyle(Color.orange)
                            }
                        }
                        Text("\(result.stroke.title) · \(result.pool.rawValue) м")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        HStack(spacing: 4) {
                            Text(result.date, format: .dateTime.day().month(.abbreviated).year())
                            if !result.competition.isEmpty {
                                Text("· \(result.competition)").lineLimit(1)
                            }
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }

                    Spacer(minLength: 8)

                    VStack(alignment: .trailing, spacing: 6) {
                        RankBadge(rank: rank, compact: true)
                        if let points {
                            Text("\(points) оч.")
                                .font(.footnote.weight(.semibold))
                                .monospacedDigit()
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(12)
                .glassCard(radius: 22)
            }
            .buttonStyle(PressableStyle())
        }
    }
}
