import SwiftUI

/// Вкладка «Дневник»: все данные пловца на одном экране.
@MainActor
struct DiaryView: View {
    @EnvironmentObject private var normatives: NormativeStore
    @EnvironmentObject private var store: ResultsStore
    @AppStorage("swimtrack.age") private var age: Int = 0

    let onAdd: () -> Void

    @State private var selectedKey: DisciplineKey?
    @State private var detail: SwimResult?
    @State private var onlySelected = false
    @State private var isImportingWorkouts = false
    @State private var importMessage: String?

    // MARK: Данные

    private var summaries: [DisciplineSummary] { DiaryStats.summaries(results: store.results) }

    /// Выбранная дисциплина (если выбор пропал после удаления — первая в списке).
    private var active: DisciplineSummary? {
        summaries.first { $0.key == selectedKey } ?? summaries.first
    }

    private var bestByPoints: ScoredResult? {
        DiaryStats.scored(store.results).max { $0.points < $1.points }
    }

    private var topRank: Rank? {
        store.results
            .compactMap { outcome($0)?.achieved }
            .min { (Rank.allCases.firstIndex(of: $0) ?? 99) < (Rank.allCases.firstIndex(of: $1) ?? 99) }
    }

    private var cardModels: [DisciplineCardModel] {
        summaries.map { s in
            DisciplineCardModel(summary: s,
                                rank: outcome(s.best)?.achieved,
                                points: FinaPoints.shared.points(for: s.best))
        }
    }

    private var history: [SwimResult] {
        let all = store.results.sorted { $0.date > $1.date }
        guard onlySelected, let key = active?.key else { return all }
        return all.filter { $0.discipline == key }
    }

    private func outcome(_ result: SwimResult) -> RankOutcome? {
        evaluate(result, normatives: normatives, age: age)
    }

    // MARK: Экран

    var body: some View {
        NavigationStack {
            List {
                if store.results.isEmpty && store.workouts.isEmpty {
                    EmptyDiaryCard(onAdd: onAdd).diaryRow()
                } else {
                    if !store.results.isEmpty {
                    if let top = bestByPoints {
                        HeroCard(scored: top, rank: outcome(top.result)?.achieved)
                            .diaryRow(top: 4, bottom: 8)
                    }

                    StatsRow(total: store.results.count, disciplines: summaries.count, topRank: topRank)
                        .diaryRow()

                    DisciplineCarousel(models: cardModels, selected: active?.key) { key in
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { selectedKey = key }
                    }
                    .diaryRow(top: 8, bottom: 4, horizontal: 0)

                    if let s = active {
                        ProgressCard(title: "\(s.key.title) · \(s.key.pool.title)",
                                     tint: s.key.stroke.tint,
                                     scored: DiaryStats.scored(s.results))
                            .diaryRow()
                        goalView(for: s).diaryRow()
                    }

                    historyHeader.diaryRow(top: 14, bottom: 2)

                    ForEach(Array(history.enumerated()), id: \.element.id) { index, result in
                        ResultRow(result: result,
                                  rank: outcome(result)?.achieved,
                                  points: FinaPoints.shared.points(for: result),
                                  isBest: DiaryStats.isPersonalBest(result, in: store.results),
                                  showMonth: index == 0 || !Calendar.current.isDate(history[index - 1].date,
                                                                                     equalTo: result.date,
                                                                                     toGranularity: .month),
                                  onTap: { detail = result })
                            .diaryRow(top: 4, bottom: 4)
                            // Свайп влево — удалить
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                Button(role: .destructive) {
                                    remove(result)
                                } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                    }

                    Color.clear.frame(height: 24).diaryRow(top: 0, bottom: 0)
                    }

                    if !store.workouts.isEmpty {
                        SectionTitle(title: "Apple Fitness", subtitle: "Импортировано тренировок: \(store.workouts.count)")
                            .diaryRow(top: 14, bottom: 4)
                        ForEach(store.workouts) { workout in
                            ImportedWorkoutRow(workout: workout)
                                .diaryRow(top: 4, bottom: 4)
                        }
                    }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background { AuroraBackground() }
            .navigationTitle("Твой дневник")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button {
                        Task { await importAppleWorkouts() }
                    } label: {
                        if isImportingWorkouts { ProgressView() }
                        else { Image(systemName: "applewatch") }
                    }
                    .disabled(isImportingWorkouts)
                    .accessibilityLabel("Импортировать из Apple Fitness")
                    Button(action: onAdd) { Image(systemName: "plus") }
                }
            }
            .alert("Apple Fitness", isPresented: Binding(
                get: { importMessage != nil }, set: { if !$0 { importMessage = nil } }
            )) {
                Button("Понятно", role: .cancel) { importMessage = nil }
            } message: {
                Text(importMessage ?? "")
            }
            .sheet(item: $detail) { result in
                ResultDetailView(result: result,
                                 isBest: DiaryStats.isPersonalBest(result, in: store.results),
                                 onDelete: { remove(result) })
            }
        }
    }

    // MARK: Части экрана

    private var historyHeader: some View {
        HStack(alignment: .bottom) {
            SectionTitle(title: "История", subtitle: "\(history.count) из \(store.results.count) заплывов")
            Spacer()
            if let key = active?.key {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { onlySelected.toggle() }
                } label: {
                    Pill(text: onlySelected ? "Только \(key.distance) м" : "Все дисциплины",
                         systemImage: "line.3.horizontal.decrease.circle",
                         tint: Theme.accent)
                }
                .buttonStyle(PressableStyle())
            }
        }
        .padding(.horizontal, 4)
    }

    @ViewBuilder
    private func goalView(for s: DisciplineSummary) -> some View {
        let n = normatives.normative(distance: s.key.distance, stroke: s.key.stroke,
                                     pool: s.key.pool, gender: s.best.gender)
        if let n {
            let o = RankCalculator.evaluate(timeMs: s.best.timeMs, normative: n, age: age > 0 ? age : nil)
            GoalCard(tint: s.key.stroke.tint,
                     current: o.achieved,
                     next: o.next,
                     gapText: o.gapText,
                     progress: DiaryStats.progress(timeMs: s.best.timeMs, normative: n, outcome: o),
                     blocked: o.blockedByAge,
                     noNormative: false)
        } else {
            GoalCard(tint: s.key.stroke.tint, current: nil, next: nil, gapText: nil,
                     progress: 0, blocked: nil, noNormative: true)
        }
    }

    private func importAppleWorkouts() async {
        guard !isImportingWorkouts else { return }
        isImportingWorkouts = true
        defer { isImportingWorkouts = false }
        do {
            let imported = try await HealthKitImportService.shared.importSwimmingWorkouts()
            let added = store.importWorkouts(imported)
            if imported.isEmpty {
                importMessage = "Тренировки плавания не найдены. Проверь, что они сохранены в Apple Health и SwimTrack разрешён доступ к данным «Здоровье» в настройках iPhone."
            } else if added == 0 {
                importMessage = "Все тренировки уже импортированы. Новых записей нет."
            } else {
                importMessage = "Добавлено тренировок: \(added). Всего найдено: \(imported.count). Повторные записи не дублируются."
            }
        } catch {
            importMessage = error.localizedDescription
        }
    }

    private func remove(_ result: SwimResult) {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            store.delete(ids: [result.id])
        }
        if detail?.id == result.id { detail = nil }
    }
}


private struct ImportedWorkoutRow: View {
    let workout: SwimWorkout
    @State private var showLaps = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("Плавание", systemImage: "figure.pool.swim")
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                Spacer()
                Text(workout.startDate, format: .dateTime.day().month(.abbreviated).year())
                    .font(.caption).foregroundStyle(.secondary)
            }
            HStack(alignment: .firstTextBaseline, spacing: 14) {
                metric(value: workout.distanceMeters.map { "\(Int($0.rounded())) м" } ?? "—", label: "Дистанция")
                metric(value: durationText(workout.durationSeconds), label: "Время")
                metric(value: workout.averagePaceSecondsPer100m.map(paceText) ?? "—", label: "/100 м")
            }
            HStack(spacing: 14) {
                if let calories = workout.activeCalories { Label("\(Int(calories.rounded())) ккал", systemImage: "flame.fill") }
                if let heartRate = workout.averageHeartRate { Label("ср. пульс \(Int(heartRate.rounded()))", systemImage: "heart.fill") }
                if let strokes = workout.strokeCount { Label("\(Int(strokes.rounded())) гребков", systemImage: "figure.pool.swim") }
            }
            .font(.caption2)
            .foregroundStyle(.secondary)
            if workout.minimumHeartRate != nil || workout.maximumHeartRate != nil {
                let minText = workout.minimumHeartRate.map { "мин \(Int($0.rounded()))" } ?? ""
                let maxText = workout.maximumHeartRate.map { "макс \(Int($0.rounded()))" } ?? ""
                Text("Пульс: \(minText) \(maxText) уд/мин")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            if let location = workout.location { Text(location).font(.caption2).foregroundStyle(.secondary) }
            if let length = workout.lapLengthMeters {
                Text("Длина дорожки: \(Int(length.rounded())) м")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            if let style = workout.strokeStyle {
                Text("Стиль: \(style)").font(.caption2).foregroundStyle(.secondary)
            }
            if let laps = workout.laps, !laps.isEmpty {
                Text("Отрезков: \(laps.count)").font(.caption2).foregroundStyle(.secondary)
            }
            if let swolf = workout.swolf {
                Text("SWOLF: \(Int(swolf.rounded()))")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            if let laps = workout.laps, !laps.isEmpty {
                DisclosureGroup("Показать отрезки (\(laps.count))", isExpanded: $showLaps) {
                    ForEach(laps) { lap in
                        HStack {
                            Text("Отрезок \(lap.number)")
                            Spacer()
                            if let style = lap.strokeStyle { Text(style).foregroundStyle(.secondary) }
                            Text(durationText(lap.durationSeconds)).monospacedDigit()
                            if let swolf = lap.swolf { Text("SWOLF \(Int(swolf.rounded()))").foregroundStyle(.secondary) }
                        }
                        .font(.caption)
                        .padding(.vertical, 3)
                    }
                }
                .font(.caption.weight(.semibold))
                .tint(Theme.accent)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 22)
    }

    private func metric(value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value).font(.system(.headline, design: .rounded).weight(.bold)).monospacedDigit()
            Text(label).font(.caption2).foregroundStyle(.secondary)
        }
    }

    private func durationText(_ seconds: Double) -> String {
        let total = Int(seconds.rounded())
        return String(format: "%d:%02d", total / 60, total % 60)
    }

    private func paceText(_ seconds: Double) -> String {
        let total = Int(seconds.rounded())
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
