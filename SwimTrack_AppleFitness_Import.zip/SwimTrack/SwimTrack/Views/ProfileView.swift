import SwiftUI

/// Вкладка «Профиль»: возраст и пол, состояние нормативов, «О приложении».
@MainActor
struct ProfileView: View {
    @EnvironmentObject private var normatives: NormativeStore
    @AppStorage("swimtrack.age") private var age: Int = 0
    @AppStorage("swimtrack.gender") private var genderRaw: String = Gender.male.rawValue

    private var gender: Binding<Gender> {
        Binding(get: { Gender(rawValue: genderRaw) ?? .male },
                set: { genderRaw = $0.rawValue })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    ageCard
                    normativesCard
                    aboutCard
                }
                .padding(16)
                .padding(.bottom, 16)
            }
            .background { AuroraBackground() }
            .navigationTitle("Профиль")
        }
    }

    // MARK: Шапка

    private var header: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle().fill(Theme.heroGradient)
                Image(systemName: "figure.pool.swim")
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 72, height: 72)
            .shadow(color: Color(hex: 0x6366F1).opacity(0.4), radius: 12, y: 6)

            VStack(alignment: .leading, spacing: 4) {
                Text("Пловец")
                    .font(.system(.title2, design: .rounded).weight(.bold))
                Text(age == 0 ? "Возраст не указан" : "\(gender.wrappedValue.title), \(ruYears(age))")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(18)
        .glassCard(radius: 30)
    }

    // MARK: Возраст и пол

    private var ageCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("О тебе")
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)

            ChipRow(items: Gender.allCases, selection: gender, title: { $0.title })

            HStack {
                Text("Возраст")
                    .font(.system(.body, design: .rounded).weight(.semibold))
                Spacer()
                roundButton("minus") {
                    age = age <= 6 ? 0 : age - 1
                }
                .disabled(age == 0)
                Text(age == 0 ? "—" : "\(age)")
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .monospacedDigit()
                    .frame(minWidth: 44)
                roundButton("plus") {
                    age = age == 0 ? 14 : min(age + 1, 90)
                }
            }

            Text("Звание КМС присваивается с 10 лет, МС — с 12, МСМК — с 14. Возраст нужен, чтобы не показывать звания, которые ещё нельзя получить.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28)
    }

    private func roundButton(_ symbol: String, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { action() }
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .bold))
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .overlay { Circle().strokeBorder(Color.white.opacity(0.35), lineWidth: 1) }
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: Нормативы

    private var normativesCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Нормативы")
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)

            HStack {
                Image(systemName: normatives.staleNotice == nil ? "checkmark.seal.fill" : "wifi.exclamationmark")
                    .foregroundStyle(normatives.staleNotice == nil ? Color.green : Color.orange)
                Text(normatives.staleNotice ?? normatives.statusText)
                    .font(.subheadline.weight(.medium))
            }

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(Gender.allCases) { g in
                    ForEach(Pool.allCases) { p in
                        countTile(gender: g, pool: p)
                    }
                }
            }

            Button {
                Haptics.tap()
                Task { await normatives.refresh(manual: true) }
            } label: {
                HStack(spacing: 8) {
                    if normatives.isRefreshing {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "arrow.clockwise")
                    }
                    Text("Обновить нормативы")
                }
                .font(.system(.headline, design: .rounded))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .foregroundStyle(.white)
                .background(Theme.accentGradient, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .shadow(color: Theme.accent.opacity(0.4), radius: 12, y: 6)
            }
            .buttonStyle(PressableStyle())
            .disabled(normatives.isRefreshing)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28)
    }

    private func countTile(gender: Gender, pool: Pool) -> some View {
        let count = normatives.normatives.filter { $0.gender == gender && $0.pool == pool }.count
        let tint = gender == .male ? Theme.stand : Theme.move
        return VStack(spacing: 2) {
            Text("\(count)")
                .font(.system(.title2, design: .rounded).weight(.bold))
                .monospacedDigit()
            Text("\(gender == .male ? "Мужчины" : "Женщины") · \(pool.title)")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: О приложении

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("О приложении")
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)

            Text("Нормативы носят справочный характер. Официальное присвоение разряда — по приказу Минспорта и протоколу соревнования. Источник нормативов: swim8.ru/standards")
                .font(.callout)

            Text("Очки считаются по формуле World Aquatics (бывш. FINA): 1000 · (B / T)³. Базовые времена: бассейн 25 м — таблица 2025 года, бассейн 50 м — таблица 2026 года.")
                .font(.footnote)
                .foregroundStyle(.secondary)

            if !normatives.repairs.isEmpty {
                DisclosureGroup("Поправлено автоматически (\(normatives.repairs.count))") {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(normatives.repairs, id: \.self) {
                            Text($0).font(.caption).foregroundStyle(.secondary)
                        }
                        Text("На сайте-источнике в этих местах опечатки или нет строки. Значения восстановлены по структуре таблицы и другим источникам. Перед важными решениями сверяйтесь с официальным приказом.")
                            .font(.caption)
                    }
                    .padding(.top, 6)
                }
                .font(.footnote)
            }

            if !normatives.skippedRows.isEmpty {
                DisclosureGroup("Строки, которые не удалось разобрать (\(normatives.skippedRows.count))") {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(normatives.skippedRows, id: \.self) {
                            Text($0).font(.caption).foregroundStyle(.secondary)
                        }
                        Text("На сайте-источнике эти строки повреждены или противоречивы, для них показывается «норматив не установлен».")
                            .font(.caption)
                    }
                    .padding(.top, 6)
                }
                .font(.footnote)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28)
    }
}
