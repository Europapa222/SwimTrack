import SwiftUI

/// Бейдж разряда с градиентом: «КМС», «II(ю)» или «—».
struct RankBadge: View {
    let rank: Rank?
    var compact = false

    var body: some View {
        Text(rank?.rawValue ?? "—")
            .font(.system(size: compact ? 12 : 14, weight: .bold, design: .rounded))
            .padding(.horizontal, compact ? 9 : 12)
            .padding(.vertical, compact ? 4 : 5)
            .foregroundStyle(rank == nil ? Color.secondary : Color.white)
            .background {
                if let rank {
                    Capsule().fill(rank.gradient)
                } else {
                    Capsule().fill(Color.secondary.opacity(0.18))
                }
            }
            .shadow(color: (rank?.tint ?? .clear).opacity(0.35), radius: 6, y: 3)
    }
}

/// Разряд результата. Считается при показе, поэтому после обновления
/// нормативов бейджи пересчитываются сами.
@MainActor
func evaluate(_ result: SwimResult, normatives: NormativeStore, age: Int) -> RankOutcome? {
    guard let normative = normatives.normative(distance: result.distance, stroke: result.stroke,
                                               pool: result.pool, gender: result.gender) else { return nil }
    return RankCalculator.evaluate(timeMs: result.timeMs, normative: normative, age: age > 0 ? age : nil)
}
