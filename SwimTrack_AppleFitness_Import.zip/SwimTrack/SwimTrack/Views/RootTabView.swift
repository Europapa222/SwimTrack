import SwiftUI

@MainActor
struct RootTabView: View {
    enum Tab: Hashable { case diary, add, profile }

    @EnvironmentObject private var normatives: NormativeStore
    @State private var tab: Tab = .diary

    var body: some View {
        TabView(selection: $tab) {
            DiaryView(onAdd: { switchTo(.add) })
                .tabItem { Label("Дневник", systemImage: "book.closed.fill") }
                .tag(Tab.diary)
            AddResultView(onFinished: { switchTo(.diary) })
                .tabItem { Label("Добавить", systemImage: "plus.circle.fill") }
                .tag(Tab.add)
            ProfileView()
                .tabItem { Label("Профиль", systemImage: "person.crop.circle.fill") }
                .tag(Tab.profile)
        }
        .tint(Theme.accent)
        .preferredColorScheme(.dark)
        .overlay(alignment: .top) {
            if let text = normatives.toast {
                ToastView(text: text)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    // Прячем через 2,5 секунды
                    .task(id: text) {
                        try? await Task.sleep(nanoseconds: 2_500_000_000)
                        normatives.toast = nil
                    }
            }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.8), value: normatives.toast)
    }

    private func switchTo(_ newTab: Tab) {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { tab = newTab }
    }
}

private struct ToastView: View {
    let text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.seal.fill")
                .foregroundStyle(Theme.accentGradient)
            Text(text)
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay { Capsule().strokeBorder(Color.white.opacity(0.4), lineWidth: 1) }
        .shadow(color: Theme.accent.opacity(0.25), radius: 14, y: 6)
    }
}
