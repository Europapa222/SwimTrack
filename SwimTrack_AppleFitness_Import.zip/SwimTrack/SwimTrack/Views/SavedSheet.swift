import SwiftUI

/// Что получилось после сохранения заплыва.
struct SavedInfo: Identifiable {
    let id = UUID()
    let result: SwimResult
    let points: Int?
    let outcome: RankOutcome?
    /// Лучшее время в этой дисциплине до сохранения (nil — заплыв первый).
    let previousBestMs: Int?

    var isRecord: Bool {
        guard let previousBestMs else { return false }
        return result.timeMs < previousBestMs
    }

    var isFirst: Bool { previousBestMs == nil }

    var improvementMs: Int? {
        guard isRecord, let previousBestMs else { return nil }
        return previousBestMs - result.timeMs
    }
}

/// Экран «Сохранено»: конфетти за личный рекорд, очки, разряд и цель.
struct SavedSheet: View {
    let info: SavedInfo
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            AuroraBackground()
            if info.isRecord { ConfettiView() }

            VStack(spacing: 12) {
                Image(systemName: info.isRecord ? "star.circle.fill" : "checkmark.circle.fill")
                    .font(.system(size: 60))
                    .foregroundStyle(info.isRecord ? AnyShapeStyle(Theme.goldGradient)
                                                   : AnyShapeStyle(Theme.accentGradient))

                Text(info.isRecord ? "Новый личный рекорд!" : "Результат сохранён")
                    .font(.system(.title2, design: .rounded).weight(.bold))

                Text("\(info.result.eventTitle) · бассейн \(info.result.pool.rawValue) м")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Text(TimeParser.format(ms: info.result.timeMs))
                    .font(.system(size: 54, weight: .heavy, design: .rounded))
                    .monospacedDigit()

                HStack(spacing: 10) {
                    if let points = info.points {
                        Pill(text: "\(points) очков FINA", systemImage: "bolt.fill", tint: Theme.accent)
                    }
                    RankBadge(rank: info.outcome?.achieved)
                }

                if let improvement = info.improvementMs {
                    Text("Быстрее прежнего рекорда на \(TimeParser.secondsText(ms: improvement)) сек")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color.green)
                } else if info.isFirst {
                    Text("Первый результат в этой дисциплине")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                if let gap = info.outcome?.gapText {
                    Text(gap.prefix(1).uppercased() + gap.dropFirst())
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else if info.outcome == nil {
                    Text("Норматив не установлен")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 8)

                Button {
                    dismiss()
                } label: {
                    Text("Открыть дневник")
                        .font(.system(.headline, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .foregroundStyle(.white)
                        .background(Theme.accentGradient, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .shadow(color: Theme.accent.opacity(0.4), radius: 14, y: 8)
                }
                .buttonStyle(PressableStyle())
            }
            .padding(24)
        }
        .presentationDetents([.medium, .large])
    }
}
