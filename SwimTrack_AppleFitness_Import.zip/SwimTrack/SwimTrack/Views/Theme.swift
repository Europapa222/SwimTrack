import SwiftUI
import UIKit

// MARK: - Цвета

extension Color {
    /// Цвет из шестнадцатеричного кода: Color(hex: 0x4F7CFF)
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

enum Theme {
    // Палитра в духе Apple Fitness: графитовая основа и три ярких цвета колец.
    static let background = Color(hex: 0x050607)
    static let surface = Color(hex: 0x17191C)
    static let surfaceElevated = Color(hex: 0x22252A)
    static let textPrimary = Color(hex: 0xF5F5F7)
    static let move = Color(hex: 0xFA315B)       // Move — розово-красный
    static let exercise = Color(hex: 0xB7F34A)   // Exercise — лаймовый
    static let stand = Color(hex: 0x35D7E8)      // Stand — бирюзовый
    static let accent = exercise

    static let accentGradient = LinearGradient(
        colors: [exercise, Color(hex: 0x78D94B)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    static let heroGradient = LinearGradient(
        colors: [Color(hex: 0x25282D), Color(hex: 0x17191C), Color(hex: 0x101214)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    static let moveGradient = LinearGradient(colors: [Color(hex: 0xFF5277), Color(hex: 0xE91649)], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let exerciseGradient = LinearGradient(colors: [Color(hex: 0xD2FF68), Color(hex: 0x83D82F)], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let standGradient = LinearGradient(colors: [Color(hex: 0x65EAF3), Color(hex: 0x16B9D0)], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let goldGradient = LinearGradient(colors: [Color(hex: 0xFFD76A), Color(hex: 0xF59E0B)], startPoint: .top, endPoint: .bottom)
}

// MARK: - Цвета разрядов и способов плавания

extension Rank {
    var colors: [Color] {
        switch self {
        case .msmk: return [Color(hex: 0xFFE18A), Color(hex: 0xF4A62A)]
        case .ms: return [Color(hex: 0xFF8A9E), Theme.move]
        case .kms: return [Color(hex: 0xD4A6FF), Color(hex: 0x9254D8)]
        case .first: return [Color(hex: 0x8CEBFF), Theme.stand]
        case .second: return [Color(hex: 0x8CEBFF), Color(hex: 0x159DB8)]
        case .third: return [Color(hex: 0xD2FF68), Theme.exercise]
        case .firstYouth: return [Color(hex: 0xB7F7A0), Color(hex: 0x69C94C)]
        case .secondYouth: return [Color(hex: 0xD8F58B), Color(hex: 0x91BD36)]
        case .thirdYouth: return [Color(hex: 0xFFE18A), Color(hex: 0xD69A28)]
        }
    }
    var gradient: LinearGradient { LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing) }
    var tint: Color { colors[1] }
}

extension Stroke {
    var colors: [Color] {
        switch self {
        case .freestyle: return [Color(hex: 0x65EAF3), Theme.stand]
        case .backstroke: return [Color(hex: 0xA3F0E5), Color(hex: 0x24BFA8)]
        case .breaststroke: return [Color(hex: 0xD2FF68), Theme.exercise]
        case .butterfly: return [Color(hex: 0xFF8A9E), Theme.move]
        case .medley: return [Color(hex: 0xD4A6FF), Color(hex: 0x9254D8)]
        }
    }

    var gradient: LinearGradient {
        LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    var tint: Color { colors[1] }
}

// MARK: - Живой фон

/// Сдержанный тёмный фон с мягкими цветовыми акцентами Fitness.
struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Theme.background
            RadialGradient(colors: [Theme.exercise.opacity(0.10), .clear], center: .topTrailing, startRadius: 10, endRadius: 360)
            RadialGradient(colors: [Theme.stand.opacity(0.07), .clear], center: .bottomLeading, startRadius: 20, endRadius: 420)
        }
        .ignoresSafeArea()
    }
}

// MARK: - Стеклянные карточки

/// «Жидкое стекло»: матовый материал, светлая рамка-блик и мягкая тень.
struct GlassCard: ViewModifier {
    var radius: CGFloat = 26
    var tint: Color?

    func body(content: Content) -> some View {
        content
            .background {
                ZStack {
                    RoundedRectangle(cornerRadius: radius, style: .continuous).fill(Theme.surface)
                    if let tint {
                        RoundedRectangle(cornerRadius: radius, style: .continuous).fill(tint.opacity(0.10))
                    }
                }
            }
            .overlay {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(
                        LinearGradient(colors: [Color.white.opacity(0.12), Color.white.opacity(0.035), Color.white.opacity(0.07)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing),
                        lineWidth: 1)
            }
            .shadow(color: Color.black.opacity(0.28), radius: 18, y: 9)
    }
}

extension View {
    func glassCard(radius: CGFloat = 26, tint: Color? = nil) -> some View {
        modifier(GlassCard(radius: radius, tint: tint))
    }
}

/// Лёгкое «вдавливание» кнопки при нажатии.
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// MARK: - Мелкие компоненты

struct Pill: View {
    let text: String
    var systemImage: String? = nil
    var tint: Color = .secondary
    var onGradient = false

    var body: some View {
        HStack(spacing: 4) {
            if let systemImage { Image(systemName: systemImage) }
            Text(text)
        }
        .font(.system(size: 12, weight: .semibold, design: .rounded))
        .padding(.horizontal, 9)
        .padding(.vertical, 4)
        .foregroundStyle(onGradient ? Color.white : tint)
        .background { Capsule().fill(onGradient ? Color.white.opacity(0.22) : tint.opacity(0.10)) }
    }
}

struct SectionTitle: View {
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.system(.title3, design: .rounded).weight(.bold))
            if let subtitle {
                Text(subtitle).font(.footnote).foregroundStyle(.secondary)
            }
        }
    }
}

/// Горизонтальный ряд «чипов» для выбора значения.
struct ChipRow<Item: Hashable>: View {
    let items: [Item]
    @Binding var selection: Item
    let title: (Item) -> String
    var tint: (Item) -> Color = { _ in Theme.accent }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(items, id: \.self) { item in
                    chip(item)
                }
            }
            .padding(.vertical, 2)
        }
    }

    private func chip(_ item: Item) -> some View {
        let selected = item == selection
        let color = tint(item)
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) { selection = item }
        } label: {
            Text(title(item))
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .foregroundStyle(selected ? Color.white : Color.primary)
                .background {
                    if selected {
                        Capsule().fill(LinearGradient(colors: [color, color.opacity(0.7)],
                                                      startPoint: .topLeading, endPoint: .bottomTrailing))
                    } else {
                        Capsule().fill(Theme.surfaceElevated)
                    }
                }
                .overlay { Capsule().strokeBorder(Color.white.opacity(selected ? 0 : 0.08), lineWidth: 1) }
                .shadow(color: selected ? color.opacity(0.4) : .clear, radius: 8, y: 4)
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - Анимации

enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}

/// Волна для декоративного «воды» в карточках.
struct WaveShape: Shape {
    var phase: Double
    var amplitude: CGFloat
    var frequency: Double

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let midY = rect.midY
        path.move(to: CGPoint(x: 0, y: rect.maxY))
        path.addLine(to: CGPoint(x: 0, y: midY))
        var x: CGFloat = 0
        while x <= rect.width {
            let angle = Double(x / max(rect.width, 1)) * frequency * 2 * .pi + phase
            path.addLine(to: CGPoint(x: x, y: midY + CGFloat(sin(angle)) * amplitude))
            x += 3
        }
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.closeSubpath()
        return path
    }
}

/// Две бегущие волны.
struct WaveLayer: View {
    var body: some View {
        TimelineView(.animation) { context in
            let t = context.date.timeIntervalSinceReferenceDate
            ZStack {
                WaveShape(phase: t * 1.1, amplitude: 9, frequency: 1.6).fill(Color.white.opacity(0.15))
                WaveShape(phase: t * 0.8 + 2, amplitude: 12, frequency: 1.1).fill(Color.white.opacity(0.12))
            }
        }
    }
}

/// Число, которое «накручивается» до значения.
struct AnimatedNumber: View {
    let target: Int
    @State private var shown: Double = 0

    var body: some View {
        CountingText(value: shown)
            .onAppear {
                withAnimation(.easeOut(duration: 1.1)) { shown = Double(target) }
            }
            .onChange(of: target) { newValue in
                withAnimation(.easeOut(duration: 0.8)) { shown = Double(newValue) }
            }
    }
}

private struct CountingText: View, Animatable {
    var value: Double
    var animatableData: Double {
        get { value }
        set { value = newValue }
    }

    var body: some View {
        Text("\(Int(value.rounded()))").monospacedDigit()
    }
}

// MARK: - Конфетти (для личного рекорда)

struct ConfettiPiece: Identifiable {
    let id = UUID()
    let x: CGFloat
    let size: CGFloat
    let color: Color
    let delay: Double
    let duration: Double
    let spin: Double
    let drift: CGFloat

    static func make(_ count: Int) -> [ConfettiPiece] {
        let palette: [Color] = [Color(hex: 0x22D3EE), Color(hex: 0xF472B6), Color(hex: 0xFBBF24),
                                Color(hex: 0x8B5CF6), Color(hex: 0x34D399)]
        return (0..<count).map { _ in
            ConfettiPiece(x: .random(in: 0...1), size: .random(in: 6...12),
                          color: palette.randomElement() ?? .pink,
                          delay: .random(in: 0...0.6), duration: .random(in: 1.6...2.8),
                          spin: .random(in: 180...720), drift: .random(in: -40...40))
        }
    }
}

struct ConfettiView: View {
    @State private var pieces = ConfettiPiece.make(44)
    @State private var fall = false

    var body: some View {
        GeometryReader { geo in
            ForEach(pieces) { piece in
                RoundedRectangle(cornerRadius: 2)
                    .fill(piece.color)
                    .frame(width: piece.size, height: piece.size * 1.6)
                    .rotationEffect(.degrees(fall ? piece.spin : 0))
                    .position(x: piece.x * geo.size.width + (fall ? piece.drift : 0),
                              y: fall ? geo.size.height + 40 : -30)
                    .animation(.easeIn(duration: piece.duration).delay(piece.delay), value: fall)
            }
        }
        .allowsHitTesting(false)
        .onAppear { fall = true }
    }
}

// MARK: - Форматирование

func ruYears(_ n: Int) -> String {
    let m10 = n % 10, m100 = n % 100
    if m10 == 1 && m100 != 11 { return "\(n) год" }
    if (2...4).contains(m10) && !(12...14).contains(m100) { return "\(n) года" }
    return "\(n) лет"
}

private let monthFormatter: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "LLLL yyyy"
    return f
}()

/// «Ноябрь 2026»
func monthTitle(_ date: Date) -> String {
    monthFormatter.string(from: date).capitalized
}
