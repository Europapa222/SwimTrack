import XCTest
@testable import SwimTrack

final class TimeParserTests: XCTestCase {
    func testFormats() {
        XCTAssertEqual(TimeParser.parseMs("1:03,84"), 63_840)
        XCTAssertEqual(TimeParser.parseMs("1.04,60"), 64_600)   // формат centrws.ru
        XCTAssertEqual(TimeParser.parseMs("27,85"), 27_850)
        XCTAssertEqual(TimeParser.parseMs("10.43,00"), 643_000)
    }

    func testCommaAfterMinutesIsRead() {
        // Опечатка на сайте: «3,56,00» вместо «3.56,00»
        XCTAssertEqual(TimeParser.parseMs("3,56,00"), 236_000)
    }

    func testBrokenCellsAreRejected() {
        XCTAssertNil(TimeParser.parseMs("30"))
        XCTAssertNil(TimeParser.parseMs("00,31,65"))
        XCTAssertNil(TimeParser.parseMs(""))
    }

    func testFormatting() {
        XCTAssertEqual(TimeParser.format(ms: 63_840), "1:03,84")
        XCTAssertEqual(TimeParser.format(ms: 27_850), "27,85")
        XCTAssertEqual(TimeParser.secondsText(ms: 50), "0,05")
    }
}

final class NormativeParserTests: XCTestCase {
    /// Минимальная копия структуры страницы: навигация, 4 раздела, эстафеты, известная опечатка
    /// («на спине 50м» у мужчин, 50 м) и таблица женщин 50 м без строки «вольный стиль 50м».
    private let sample = """
    Мужчины. Бассейн 50м Женщины. Бассейн 50м Мужчины. Бассейн 25м Женщины. Бассейн 25м \
    МУЖЧИНЫ. БАССЕЙН 50м Дисциплина;МСМК;МС;КМС;I;II;III;Iюн;IIюн;IIIюн \
    вольный стиль 100м;47,71;51,50;54,90;58,30;1.04,60;1.12,10;1.24,60;1.44,60;2.04,60 \
    на спине 50м;24,51;26,65;28,15;29,95;32,80;26,30;42,30;52,30;1.02,30 \
    4х100м вольный стиль*;47,71;51,50;54,90;58,30;1.04,60;1.12,10;1.24,60;1.44,60;2.04,60 *только для спортсмена стартующего первым \
    ЖЕНЩИНЫ. БАССЕЙН 50м Дисциплина;МСМК;МС;КМС;I;II;III;Iюн;IIюн;IIIюн \
    вольный стиль 100м;53,22;57,50;1.01,50;1.05,34;1.12,90;1.20,60;1.34,60;1.54,60;2.13,60 \
    МУЖЧИНЫ. БАССЕЙН 25м Дисциплина;МСМК;МС;КМС;I;II;III;Iюн;IIюн;IIIюн \
    комплексное плавание 100м;51,87;56,50;1.01,50;1.05,50;1.13,60;1.23,60;1.34,60;1.53,60;2.13,60 \
    ЖЕНЩИНЫ. БАССЕЙН 25м Дисциплина;МСМК;МС;КМС;I;II;III;Iюн;IIюн;IIIюн \
    вольный стиль 100м;51,95;56,00;1.00,00;1.03,84;1.11,40;1.19,10;1.33,10;1.53,10;2.12,10
    """

    func testFindsAllFourTables() throws {
        let report = try NormativeParser.parse(text: sample)
        XCTAssertEqual(report.tablesFound, 4)
        // М 50: вольный 100 + «на спине 50м» (опечатка исправлена); Ж 50: вольный 100 + добавленный вольный 50;
        // по одной строке в таблицах 25 м. Эстафеты не берём.
        XCTAssertEqual(report.normatives.count, 6)
        XCTAssertTrue(report.skippedRows.isEmpty)
        XCTAssertEqual(report.repairs.count, 2)          // исправление опечатки + добавленная строка
    }

    func testUnknownTypoIsStillSkipped() throws {
        // Опечатка, которой нет в таблице известных: строка пропускается, а не «угадывается»
        let broken = sample.replacingOccurrences(of: "вольный стиль 100м;47,71;51,50;54,90;58,30;1.04,60;1.12,10;1.24,60;1.44,60;2.04,60 на спине",
                                                 with: "вольный стиль 100м;47,71;51,50;54,90;58,30;1.04,60;0.12,10;1.24,60;1.44,60;2.04,60 на спине")
        let report = try NormativeParser.parse(text: broken)
        XCTAssertEqual(report.skippedRows.count, 1)
    }

    func testRankValues() throws {
        let report = try NormativeParser.parse(text: sample)
        let n = report.normatives.first { $0.gender == .female && $0.pool == .m25 && $0.distance == 100 }
        XCTAssertEqual(n?.ranks[.first], 63_840)
        XCTAssertEqual(n?.ranks[.thirdYouth], 132_100)
    }

    func testNoTablesIsError() {
        XCTAssertThrowsError(try NormativeParser.parse(text: "Страница без таблиц"))
    }

    func testIncompleteSetIsError() {
        XCTAssertThrowsError(try NormativeParser.parse(text: "МУЖЧИНЫ. БАССЕЙН 50м вольный стиль 100м;47,71;51,50;54,90;58,30;1.04,60;1.12,10;1.24,60;1.44,60;2.04,60"))
    }
}

/// Разбор полного текста страницы centrws.ru/evsk (EvskFixture) вместе с её опечатками.
final class FullPageTests: XCTestCase {
    private func report() throws -> ParseReport { try NormativeParser.parse(text: EvskFixture.text) }

    private func find(_ report: ParseReport, _ g: Gender, _ p: Pool, _ s: Stroke, _ d: Int) -> Normative? {
        report.normatives.first { $0.gender == g && $0.pool == p && $0.stroke == s && $0.distance == d }
    }

    func testAllDisciplinesAreParsed() throws {
        let r = try report()
        func count(_ g: Gender, _ p: Pool) -> Int { r.normatives.filter { $0.gender == g && $0.pool == p }.count }
        XCTAssertEqual(count(.male, .m50), 17)
        XCTAssertEqual(count(.female, .m50), 17)
        XCTAssertEqual(count(.male, .m25), 18)
        XCTAssertEqual(count(.female, .m25), 18)
        XCTAssertTrue(r.skippedRows.isEmpty, "Пропущены: \(r.skippedRows)")
        // 2 исправленных значения + 2 исправленных ячейки + 1 добавленная строка
        XCTAssertEqual(r.repairs.count, 5, "Поправки: \(r.repairs)")
    }

    func testRepairedRowsHaveExpectedValues() throws {
        let r = try report()
        XCTAssertEqual(find(r, .male, .m50, .backstroke, 50)?.ranks[.third], 36_300)
        XCTAssertEqual(find(r, .female, .m25, .backstroke, 50)?.ranks[.second], 36_550)
        XCTAssertEqual(find(r, .male, .m25, .freestyle, 400)?.ranks[.ms], 236_000)
        let breast = find(r, .male, .m25, .breaststroke, 50)
        XCTAssertEqual(breast?.ranks[.kms], 30_000)
        XCTAssertEqual(breast?.ranks[.first], 31_650)
    }

    func testWomen50mFreestyle50IsAddedWithoutMsmk() throws {
        let r = try report()
        let n = find(r, .female, .m50, .freestyle, 50)
        XCTAssertEqual(n?.ranks[.kms], 27_300)
        XCTAssertEqual(n?.ranks[.thirdYouth], 59_800)
        XCTAssertNil(n?.ranks[.msmk])
    }

    func testEveryRowIsStrictlyOrdered() throws {
        for n in try report().normatives {
            let times = Rank.columnOrder.compactMap { n.ranks[$0] }
            XCTAssertEqual(times, times.sorted(), n.key)
            XCTAssertEqual(Set(times).count, times.count, n.key)
        }
    }
}

final class Swim8ParserTests: XCTestCase {
    func testParsesSelectedGenderAndPoolFromSwim8Rows() throws {
        let disciplines = [
            "50м Вольный стиль", "100м Вольный стиль", "200м Вольный стиль",
            "400м Вольный стиль", "800м Вольный стиль", "1500м Вольный стиль",
            "50м На спине", "100м На спине", "200м На спине",
            "50м Брасс", "100м Брасс", "200м Брасс",
            "50м Баттерфляй", "100м Баттерфляй", "200м Баттерфляй",
            "100м Комплексное плавание", "200м Комплексное плавание", "400м Комплексное плавание"
        ]
        let rows = disciplines.map { "\($0), Женщины 24.13 25.75 26.55 27.85 30.55 32.55 39.55 49.55 59.05" }
        let html = "<html><body>" + rows.joined(separator: " ") + "</body></html>"
        let report = try NormativeParser.parseSwim8(html: html, pool: .m25, gender: .female)

        XCTAssertEqual(report.tablesFound, 1)
        XCTAssertEqual(report.normatives.count, 17)
        let freestyle = report.normatives.first { $0.stroke == .freestyle && $0.distance == 50 }
        XCTAssertEqual(freestyle?.pool, .m25)
        XCTAssertEqual(freestyle?.gender, .female)
        XCTAssertEqual(freestyle?.ranks[.msmk], 24_130)
        XCTAssertEqual(freestyle?.ranks[.thirdYouth], 59_050)
    }

    func testMissingSwim8RankRemainsUnset() throws {
        let disciplines = [
            "50м Вольный стиль", "100м Вольный стиль", "200м Вольный стиль", "400м Вольный стиль", "800м Вольный стиль", "1500м Вольный стиль",
            "50м На спине", "100м На спине", "200м На спине", "50м Брасс", "100м Брасс", "200м Брасс",
            "50м Баттерфляй", "100м Баттерфляй", "200м Баттерфляй", "100м Комплексное плавание", "200м Комплексное плавание", "400м Комплексное плавание"
        ].map { "\($0), Женщины 24.13 25.75 26.55 27.85 30.55 32.55 39.55 49.55 -" }
        let html = "<html><body>" + disciplines.joined(separator: " ") + "</body></html>"
        let report = try NormativeParser.parseSwim8(html: html, pool: .m25, gender: .female)
        XCTAssertNil(report.normatives.first?.ranks[.thirdYouth])
    }
}

final class RankCalculatorTests: XCTestCase {
    private let normative = Normative(
        distance: 100, stroke: .freestyle, pool: .m25, gender: .female,
        ranks: [.msmk: 51_950, .ms: 56_000, .kms: 60_000, .first: 63_840, .second: 71_400,
                .third: 79_100, .firstYouth: 93_100, .secondYouth: 113_100, .thirdYouth: 132_100])

    func testExactNormativeCounts() {
        let o = RankCalculator.evaluate(timeMs: 63_840, normative: normative, age: 20)
        XCTAssertEqual(o.achieved, .first)
        XCTAssertEqual(o.next, .kms)
        XCTAssertEqual(o.gapMs, 3_840)
    }

    func testNoRank() {
        let o = RankCalculator.evaluate(timeMs: 140_000, normative: normative, age: 20)
        XCTAssertNil(o.achieved)
        XCTAssertEqual(o.next, .thirdYouth)
    }

    func testAgeBlocksTitles() {
        // Время мастера спорта, но спортсменке 9 лет: КМС/МС/МСМК не присваиваются
        let o = RankCalculator.evaluate(timeMs: 55_000, normative: normative, age: 9)
        XCTAssertEqual(o.achieved, .first)
        XCTAssertEqual(o.blockedByAge, .ms)
    }

    func testGapText() {
        let n = Normative(distance: 50, stroke: .freestyle, pool: .m50, gender: .male,
                          ranks: [.first: 25_200, .second: 27_600])
        let o = RankCalculator.evaluate(timeMs: 25_250, normative: n, age: nil)
        XCTAssertEqual(o.achieved, .second)
        XCTAssertEqual(o.gapText, "до I разряда не хватает 0,05 сек")
    }

    func testMissingRanksAreSkipped() {
        let n = Normative(distance: 100, stroke: .medley, pool: .m50, gender: .female, ranks: [:])
        let o = RankCalculator.evaluate(timeMs: 70_000, normative: n, age: 20)
        XCTAssertNil(o.achieved)
        XCTAssertNil(o.next)
    }
}

final class FinaPointsTests: XCTestCase {
    func testBaseTimeGivesThousand() {
        // Базовое время мужчин, 100 в/с, 50 м = 46,40 → ровно 1000 очков
        // (тесты запускаются внутри приложения, поэтому справочник лежит в Bundle.main)
        let p = FinaPoints.shared.points(timeMs: 46_400, gender: .male, pool: .m50,
                                         distance: 100, stroke: .freestyle)
        XCTAssertEqual(p, 1000)
    }

    func testSlowerSwimScoresLess() {
        let p = FinaPoints.shared.points(timeMs: 50_000, gender: .male, pool: .m50,
                                         distance: 100, stroke: .freestyle)
        XCTAssertNotNil(p)
        XCTAssertLessThan(p ?? 0, 1000)
    }
}

final class ImportedWorkoutModelTests: XCTestCase {
    func testAveragePaceIsCalculatedFromDurationAndDistance() {
        let now = Date()
        let workout = SwimWorkout(
            healthKitID: "healthkit-test",
            startDate: now,
            endDate: now.addingTimeInterval(1_200),
            durationSeconds: 1_200,
            distanceMeters: 1_000,
            activeCalories: 300,
            averageHeartRate: 140,
            minimumHeartRate: 95,
            maximumHeartRate: 165,
            strokeCount: 500,
            lapLengthMeters: 25,
            swolf: 42,
            strokeStyle: "Вольный стиль",
            location: "Бассейн",
            laps: nil
        )
        XCTAssertEqual(workout.averagePaceSecondsPer100m ?? -1, 120, accuracy: 0.001)
    }

    func testAveragePaceIsMissingWhenDistanceIsMissing() {
        let now = Date()
        let workout = SwimWorkout(
            healthKitID: "healthkit-test-empty",
            startDate: now,
            endDate: now.addingTimeInterval(300),
            durationSeconds: 300,
            distanceMeters: nil,
            activeCalories: nil,
            averageHeartRate: nil,
            minimumHeartRate: nil,
            maximumHeartRate: nil,
            strokeCount: nil,
            lapLengthMeters: nil,
            swolf: nil,
            strokeStyle: nil,
            location: nil,
            laps: nil
        )
        XCTAssertNil(workout.averagePaceSecondsPer100m)
    }
}
