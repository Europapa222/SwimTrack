import Foundation
import HealthKit

/// Результаты пловца — JSON-файл в Documents.
@MainActor
final class ResultsStore: ObservableObject {
    @Published private(set) var results: [SwimResult] = []
    @Published private(set) var workouts: [SwimWorkout] = []
    /// Растёт при каждом изменении тренировок (импорт, привязка) — по нему пересчитывается статистика.
    @Published private(set) var workoutsRevision = 0

    private let fileURL: URL

    init(fileURL: URL? = nil) {
        if let fileURL {
            self.fileURL = fileURL
        } else {
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            self.fileURL = docs.appendingPathComponent("swim_results.json")
        }
        load()
        loadWorkouts()
    }

    func add(_ result: SwimResult) {
        results.append(result)
        save()
    }

    /// Заменяет результат с тем же id (правка).
    func update(_ result: SwimResult) {
        guard let index = results.firstIndex(where: { $0.id == result.id }) else { return }
        results[index] = result
        save()
    }

    func delete(ids: [UUID]) {
        results.removeAll { ids.contains($0.id) }
        save()
    }

    func importWorkouts(_ imported: [SwimWorkout]) -> Int {
        let knownIDs = Set(workouts.map(\.healthKitID))
        let fresh = imported.filter { !knownIDs.contains($0.healthKitID) }
        guard !fresh.isEmpty else { return 0 }
        workouts.append(contentsOf: fresh)
        workouts.sort { $0.startDate > $1.startDate }
        workoutsRevision += 1
        saveWorkouts()
        return fresh.count
    }

    /// Привязка тренировки к способу плавания и длине бассейна (nil = определять автоматически).
    func setLink(workoutID: UUID, stroke: Stroke?, pool: Pool?) {
        guard let index = workouts.firstIndex(where: { $0.id == workoutID }) else { return }
        workouts[index].linkedStroke = stroke
        workouts[index].linkedPool = pool
        workoutsRevision += 1
        saveWorkouts()
    }

    /// Проставляет способ всем тренировкам, у которых он не определён.
    @discardableResult
    func assignStrokeToUnlinked(_ stroke: Stroke) -> Int {
        var count = 0
        for index in workouts.indices where workouts[index].effectiveStroke == nil {
            workouts[index].linkedStroke = stroke
            count += 1
        }
        if count > 0 { workoutsRevision += 1; saveWorkouts() }
        return count
    }

    private var workoutsFileURL: URL {
        fileURL.deletingLastPathComponent().appendingPathComponent("swim_workouts.json")
    }

    private func loadWorkouts() {
        guard let data = try? Data(contentsOf: workoutsFileURL),
              let loaded = try? JSONDecoder.iso8601.decode([SwimWorkout].self, from: data) else { return }
        workouts = loaded.sorted { $0.startDate > $1.startDate }
    }

    private func saveWorkouts() {
        do {
            let data = try JSONEncoder.iso8601.encode(workouts)
            try data.write(to: workoutsFileURL, options: .atomic)
        } catch {
            print("[Workouts] Не удалось сохранить: \(error.localizedDescription)")
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        if let loaded = try? decoder.decode([SwimResult].self, from: data) {
            results = loaded
        }
    }

    private func save() {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            let data = try encoder.encode(results)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            print("[Results] Не удалось сохранить: \(error.localizedDescription)")
        }
    }
}


/// Отдельная модель тренировки: она не смешивается с соревновательными результатами и нормативами.
struct SwimWorkout: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var healthKitID: String
    var startDate: Date
    var endDate: Date
    var durationSeconds: Double
    var distanceMeters: Double?
    var activeCalories: Double?
    var averageHeartRate: Double?
    var minimumHeartRate: Double?
    var maximumHeartRate: Double?
    var strokeCount: Double?
    var lapLengthMeters: Double?
    var swolf: Double?
    var strokeStyle: String?
    var location: String?
    var laps: [SwimWorkoutLap]?
    /// Выбранные пользователем способ и бассейн. Старые файлы без этих полей читаются как nil.
    var linkedStroke: Stroke? = nil
    var linkedPool: Pool? = nil

    /// Способ из данных Apple Health, если в тренировке один стиль.
    var suggestedStroke: Stroke? {
        guard let strokeStyle else { return nil }
        let parts = strokeStyle.components(separatedBy: " · ")
        guard parts.count == 1, let only = parts.first else { return nil }
        switch only {
        case "Вольный стиль": return .freestyle
        case "На спине": return .backstroke
        case "Брасс": return .breaststroke
        case "Баттерфляй": return .butterfly
        case "Смешанный": return .medley
        default: return nil
        }
    }

    /// Длина бассейна по длине дорожки из Apple Health.
    var suggestedPool: Pool? {
        guard let lapLengthMeters else { return nil }
        if abs(lapLengthMeters - 25) < 2 { return .m25 }
        if abs(lapLengthMeters - 50) < 2 { return .m50 }
        return nil
    }

    var effectiveStroke: Stroke? { linkedStroke ?? suggestedStroke }
    var effectivePool: Pool? { linkedPool ?? suggestedPool }

    var averagePaceSecondsPer100m: Double? {
        guard let distanceMeters, distanceMeters > 0 else { return nil }
        return durationSeconds / distanceMeters * 100
    }
}

struct SwimWorkoutLap: Codable, Equatable, Identifiable {
    var number: Int
    var startDate: Date
    var endDate: Date
    var strokeStyle: String?
    var swolf: Double?
    var id: Int { number }
    var durationSeconds: Double { max(0, endDate.timeIntervalSince(startDate)) }
}

@MainActor
final class HealthKitImportService {
    static let shared = HealthKitImportService()
    private let healthStore = HKHealthStore()

    enum ImportError: LocalizedError {
        case unavailable
        case authorizationFailed
        case queryFailed(String)

        var errorDescription: String? {
            switch self {
            case .unavailable: return "Apple Health недоступен на этом устройстве."
            case .authorizationFailed: return "Не удалось запросить доступ к Apple Health. Проверь разрешения в настройках."
            case .queryFailed(let message): return "Не удалось прочитать тренировки: \(message)"
            }
        }
    }

    func importSwimmingWorkouts() async throws -> [SwimWorkout] {
        guard HKHealthStore.isHealthDataAvailable() else { throw ImportError.unavailable }

        let workoutType = HKObjectType.workoutType()
        var readTypes: Set<HKObjectType> = [workoutType]
        let identifiers: [HKQuantityTypeIdentifier] = [
            .distanceSwimming, .activeEnergyBurned, .heartRate, .swimmingStrokeCount
        ]
        for identifier in identifiers {
            if let type = HKObjectType.quantityType(forIdentifier: identifier) {
                readTypes.insert(type)
            }
        }

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            healthStore.requestAuthorization(toShare: [], read: readTypes) { success, error in
                if let error { continuation.resume(throwing: error) }
                else if success { continuation.resume() }
                else { continuation.resume(throwing: ImportError.authorizationFailed) }
            }
        }

        let workouts: [HKWorkout] = try await withCheckedThrowingContinuation { continuation in
            let predicate = HKQuery.predicateForWorkouts(with: .swimming)
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
            let query = HKSampleQuery(sampleType: workoutType, predicate: predicate,
                                      limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, error in
                if let error { continuation.resume(throwing: ImportError.queryFailed(error.localizedDescription)); return }
                continuation.resume(returning: (samples as? [HKWorkout]) ?? [])
            }
            healthStore.execute(query)
        }

        return workouts.map(makeWorkout)
    }

    private func makeWorkout(_ workout: HKWorkout) -> SwimWorkout {
        func quantity(_ identifier: HKQuantityTypeIdentifier, unit: HKUnit,
                      statistic: (HKStatistics) -> HKQuantity? = { $0.sumQuantity() }) -> Double? {
            guard let type = HKObjectType.quantityType(forIdentifier: identifier),
                  let stats = workout.statistics(for: type),
                  let value = statistic(stats) else { return nil }
            return value.doubleValue(for: unit)
        }

        let metadata = workout.metadata ?? [:]
        let lapLength: Double? = {
            if let value = metadata[HKMetadataKeyLapLength] as? HKQuantity {
                return value.doubleValue(for: .meter())
            }
            if let value = metadata[HKMetadataKeyLapLength] as? NSNumber { return value.doubleValue }
            return nil
        }()
        let swolf = (metadata[HKMetadataKeySWOLFScore] as? NSNumber)?.doubleValue
        let location: String? = {
            guard let raw = (metadata[HKMetadataKeySwimmingLocationType] as? NSNumber)?.intValue else { return nil }
            switch raw {
            case 1: return "Бассейн"
            case 2: return "Открытая вода"
            default: return nil
            }
        }()
        let lapEvents = (workout.workoutEvents ?? []).filter { $0.type == .lap }
        let laps: [SwimWorkoutLap] = lapEvents.enumerated().compactMap { index, event in
            let lapMetadata = event.metadata ?? [:]
            let style: String? = {
                guard let raw = (lapMetadata[HKMetadataKeySwimmingStrokeStyle] as? NSNumber)?.intValue else { return nil }
                switch raw {
                case 1: return "Смешанный"
                case 2: return "Вольный стиль"
                case 3: return "На спине"
                case 4: return "Брасс"
                case 5: return "Баттерфляй"
                default: return nil
                }
            }()
            let lapSwolf = (lapMetadata[HKMetadataKeySWOLFScore] as? NSNumber)?.doubleValue
            return SwimWorkoutLap(number: index + 1, startDate: event.dateInterval.start,
                                  endDate: event.dateInterval.end, strokeStyle: style, swolf: lapSwolf)
        }
        let workoutStrokeStyle = laps.compactMap(\.strokeStyle).reduce(into: [String]()) { values, value in
            if !values.contains(value) { values.append(value) }
        }.joined(separator: " · ")

        return SwimWorkout(
            healthKitID: workout.uuid.uuidString,
            startDate: workout.startDate,
            endDate: workout.endDate,
            durationSeconds: workout.duration,
            distanceMeters: quantity(.distanceSwimming, unit: .meter()),
            activeCalories: quantity(.activeEnergyBurned, unit: .kilocalorie()),
            averageHeartRate: quantity(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()), statistic: { $0.averageQuantity() }),
            minimumHeartRate: quantity(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()), statistic: { $0.minimumQuantity() }),
            maximumHeartRate: quantity(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()), statistic: { $0.maximumQuantity() }),
            strokeCount: quantity(.swimmingStrokeCount, unit: .count()),
            lapLengthMeters: lapLength,
            swolf: swolf,
            strokeStyle: workoutStrokeStyle.isEmpty ? nil : workoutStrokeStyle,
            location: location,
            laps: laps.isEmpty ? nil : laps
        )
    }
}

private extension JSONEncoder {
    static var iso8601: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return encoder
    }
}

private extension JSONDecoder {
    static var iso8601: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
