import Foundation

/// Темп одной тренировки (секунд на 100 м). Чем меньше, тем быстрее.
struct PacePoint: Identifiable, Equatable {
    let id: UUID
    let date: Date
    let pace: Double
    let distance: Double
}

/// Изменение показателя между двумя периодами.
struct MetricChange: Equatable {
    let current: Double
    let previous: Double

    var delta: Double { current - previous }
    var percent: Double { previous == 0 ? 0 : delta / previous * 100 }
}

enum TrendVerdict: Equatable {
    case improving, declining, stable, notEnough
}

struct WorkoutTrend {
    /// Старые первыми.
    let points: [PacePoint]
    /// Скользящее среднее темпа, чтобы шум отдельных тренировок не скрывал тенденцию.
    let smoothed: [PacePoint]
    let pace: MetricChange?
    let swolf: MetricChange?
    /// Метры в неделю: последние 4 недели против предыдущих 4.
    let volume: MetricChange?
    let verdict: TrendVerdict
    /// Сколько тренировок в каждой из двух групп сравнения.
    let groupSize: Int
    let bestPace: PacePoint?

    static let empty = WorkoutTrend(points: [], smoothed: [], pace: nil, swolf: nil, volume: nil,
                                    verdict: .notEnough, groupSize: 0, bestPace: nil)
}

enum WorkoutStats {
    /// Порог «без изменений»: меньше 1,5 % от темпа.
    static let stablePercent = 1.5
    /// Отсекаем разминки и ошибочные записи.
    static let minDistance = 200.0
    static let paceRange = 30.0...400.0

    static func trend(workouts: [SwimWorkout], now: Date = Date()) -> WorkoutTrend {
        let valid = workouts
            .filter { w in
                guard let d = w.distanceMeters, d >= minDistance,
                      let p = w.averagePaceSecondsPer100m else { return false }
                return paceRange.contains(p)
            }
            .sorted { $0.startDate < $1.startDate }

        let points = valid.compactMap { w -> PacePoint? in
            guard let pace = w.averagePaceSecondsPer100m, let d = w.distanceMeters else { return nil }
            return PacePoint(id: w.id, date: w.startDate, pace: pace, distance: d)
        }
        let smoothed = movingAverage(points, window: 4)
        let best = points.min { $0.pace < $1.pace }

        // Две группы подряд: последние n тренировок и n перед ними.
        let n = min(5, valid.count / 2)
        guard n >= 2 else {
            return WorkoutTrend(points: points, smoothed: smoothed, pace: nil, swolf: nil,
                                volume: volume(in: workouts, now: now),
                                verdict: .notEnough, groupSize: 0, bestPace: best)
        }
        let recent = Array(valid.suffix(n))
        let previous = Array(valid.dropLast(n).suffix(n))

        let paceChange = MetricChange(current: weightedPace(recent), previous: weightedPace(previous))
        let swolfChange = average(recent.compactMap(\.swolf)).flatMap { cur in
            average(previous.compactMap(\.swolf)).map { MetricChange(current: cur, previous: $0) }
        }

        let verdict: TrendVerdict
        if abs(paceChange.percent) < stablePercent { verdict = .stable }
        else { verdict = paceChange.delta < 0 ? .improving : .declining }

        return WorkoutTrend(points: points, smoothed: smoothed, pace: paceChange, swolf: swolfChange,
                            volume: volume(in: workouts, now: now),
                            verdict: verdict, groupSize: n, bestPace: best)
    }

    /// Темп, взвешенный по дистанции: длинные заплывы весят больше коротких.
    private static func weightedPace(_ list: [SwimWorkout]) -> Double {
        let distance = list.reduce(0) { $0 + ($1.distanceMeters ?? 0) }
        let time = list.reduce(0) { $0 + $1.durationSeconds }
        return distance > 0 ? time / distance * 100 : 0
    }

    private static func average(_ values: [Double]) -> Double? {
        values.isEmpty ? nil : values.reduce(0, +) / Double(values.count)
    }

    private static func movingAverage(_ points: [PacePoint], window: Int) -> [PacePoint] {
        guard points.count >= 3 else { return [] }
        return points.indices.map { i in
            let slice = points[max(0, i - window + 1)...i]
            let avg = slice.reduce(0) { $0 + $1.pace } / Double(slice.count)
            return PacePoint(id: points[i].id, date: points[i].date, pace: avg, distance: points[i].distance)
        }
    }

    private static func volume(in workouts: [SwimWorkout], now: Date) -> MetricChange? {
        let day = 86_400.0
        let recentStart = now.addingTimeInterval(-28 * day)
        let previousStart = now.addingTimeInterval(-56 * day)
        func sum(from: Date, to: Date) -> Double {
            workouts.filter { $0.startDate >= from && $0.startDate < to }
                .reduce(0) { $0 + ($1.distanceMeters ?? 0) }
        }
        let cur = sum(from: recentStart, to: now.addingTimeInterval(1))
        let prev = sum(from: previousStart, to: recentStart)
        guard cur > 0 || prev > 0 else { return nil }
        return MetricChange(current: cur / 4, previous: prev / 4)
    }
}

// MARK: - Прогресс на одной и той же дистанции

/// Тренировка, приведённая к «круглой» дистанции: время пересчитано на ровные 500 м, 1000 м и т. д.
struct DistancePoint: Identifiable, Equatable {
    let id: UUID
    let date: Date
    let seconds: Double
    let actualDistance: Double
}

struct DistanceProgress: Identifiable {
    let distance: Int
    /// Способ и бассейн (nil — у тренировок они не указаны).
    let stroke: Stroke?
    let pool: Pool?
    /// Старые первыми.
    let points: [DistancePoint]
    /// Время в начале (среднее первых тренировок) и сейчас (среднее последних).
    let baseline: Double
    let latest: Double
    let best: DistancePoint
    let verdict: TrendVerdict

    var id: String { "\(distance)-\(stroke?.rawValue ?? "any")-\(pool?.rawValue ?? 0)" }
    var title: String {
        var parts = ["\(distance) м"]
        if let stroke { parts.append(stroke.title) }
        if let pool { parts.append("\(pool.rawValue) м бассейн") }
        return parts.joined(separator: " · ")
    }
    var change: MetricChange { MetricChange(current: latest, previous: baseline) }
}

extension WorkoutStats {
    /// Стандартные дистанции, к которым притягиваются тренировки.
    static let buckets = [100, 200, 300, 400, 500, 600, 750, 800, 1000, 1200, 1500, 1600, 2000, 2500, 3000, 4000, 5000]
    /// Тренировка попадает в группу, если её дистанция отличается не больше чем на 8 %.
    static let bucketTolerance = 0.08

    static func distanceProgress(workouts: [SwimWorkout]) -> [DistanceProgress] {
        struct Key: Hashable { let bucket: Int; let stroke: Stroke?; let pool: Pool? }
        var groups: [Key: [DistancePoint]] = [:]
        for w in workouts {
            guard let d = w.distanceMeters, d >= 100, w.durationSeconds > 0,
                  let bucket = buckets.min(by: { abs(Double($0) - d) < abs(Double($1) - d) }),
                  abs(Double(bucket) - d) / Double(bucket) <= bucketTolerance else { continue }
            let seconds = w.durationSeconds * Double(bucket) / d
            groups[Key(bucket: bucket, stroke: w.effectiveStroke, pool: w.effectivePool), default: []].append(
                DistancePoint(id: w.id, date: w.startDate, seconds: seconds, actualDistance: d))
        }
        return groups.compactMap { key, raw -> DistanceProgress? in
            let pts = raw.sorted { $0.date < $1.date }
            guard pts.count >= 2, let best = pts.min(by: { $0.seconds < $1.seconds }) else { return nil }
            // При 4+ тренировках сравниваем средние по двум концам, чтобы одна случайная не решала всё.
            let k = pts.count >= 4 ? 2 : 1
            let base = pts.prefix(k).reduce(0) { $0 + $1.seconds } / Double(k)
            let last = pts.suffix(k).reduce(0) { $0 + $1.seconds } / Double(k)
            let change = MetricChange(current: last, previous: base)
            let verdict: TrendVerdict
            if abs(change.percent) < stablePercent { verdict = .stable }
            else { verdict = change.delta < 0 ? .improving : .declining }
            return DistanceProgress(distance: key.bucket, stroke: key.stroke, pool: key.pool,
                                    points: pts, baseline: base, latest: last, best: best, verdict: verdict)
        }
        .sorted { $0.points.count != $1.points.count ? $0.points.count > $1.points.count : $0.id < $1.id }
    }
}
