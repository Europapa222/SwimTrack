import SwiftUI

/// Вкладка «Добавить»: чипы вместо выпадающих списков и живой предпросмотр очков и разряда.
@MainActor
struct AddResultView: View {
    @EnvironmentObject private var normatives: NormativeStore
    @EnvironmentObject private var store: ResultsStore

    /// 0 — возраст ещё не вводили
    @AppStorage("swimtrack.age") private var age: Int = 0
    @AppStorage("swimtrack.gender") private var genderRaw: String = Gender.male.rawValue

    /// Результат, который правим. nil — обычное добавление нового.
    let editing: SwimResult?
    let onFinished: () -> Void

    init(editing: SwimResult? = nil, onFinished: @escaping () -> Void) {
        self.editing = editing
        self.onFinished = onFinished
    }

    @Environment(\.dismiss) private var dismiss
    @State private var editGender: Gender?
    @State private var didPrefill = false
    private var isEditing: Bool { editing != nil }

    @State private var pool: Pool = .m50
    @State private var stroke: Stroke = .freestyle
    @State private var distance = 100
    @State private var minutesText = ""
    @State private var secondsText = ""
    @State private var hundredthsText = ""
    @State private var date = Date()
    @State private var competition = ""

    @State private var showAgeSheet = false
    @State private var saved: SavedInfo?
    @FocusState private var focus: Field?

    enum Field { case minutes, seconds, hundredths, competition }

    private var gender: Binding<Gender> {
        Binding(get: { editGender ?? Gender(rawValue: genderRaw) ?? .male },
                set: { newValue in
                    // При правке пол меняется только у этого результата, а не в настройках профиля
                    if isEditing { editGender = newValue } else { genderRaw = newValue.rawValue }
                })
    }

    private var distances: [Int] {
        EventCatalog.distances(stroke: stroke, pool: pool)
    }

    /// Время в мс из трёх полей: минуты, секунды и сотые доли секунды.
    /// Сотые дополняются справа: «5» = 50 (как в записи 27,5 = 27,50).
    private var timeMs: Int? {
        let minutes = minutesText.isEmpty ? 0 : Int(minutesText)
        let seconds = secondsText.isEmpty ? 0 : Int(secondsText)
        guard let minutes, let seconds, minutes >= 0, seconds >= 0, seconds < 60 else { return nil }
        let padded = hundredthsText.padding(toLength: 2, withPad: "0", startingAt: 0)
        guard let hundredths = hundredthsText.isEmpty ? 0 : Int(padded) else { return nil }
        let ms = minutes * 60_000 + seconds * 1000 + hundredths * 10
        return ms > 0 ? ms : nil
    }

    private var draft: SwimResult? {
        guard let t = timeMs else { return nil }
        return SwimResult(distance: distance, stroke: stroke, pool: pool, timeMs: t, date: date,
                          competition: "", gender: gender.wrappedValue)
    }

    // MARK: Экран

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    preview

                    card("Кто плывёт") {
                        ChipRow(items: Gender.allCases, selection: gender, title: { $0.title })
                    }
                    card("Бассейн") {
                        ChipRow(items: Pool.allCases, selection: $pool, title: { $0.title })
                    }
                    card("Способ") {
                        ChipRow(items: Stroke.allCases, selection: $stroke, title: { $0.title },
                                tint: { $0.tint })
                    }
                    card("Дистанция") {
                        ChipRow(items: distances, selection: $distance, title: { "\($0) м" },
                                tint: { _ in stroke.tint })
                    }
                    card("Время") { timeInput }
                    card("Детали") {
                        DatePicker("Дата", selection: $date, in: ...Date(), displayedComponents: .date)
                            .font(.system(.body, design: .rounded))
                        HStack(spacing: 10) {
                            Image(systemName: "flag.fill").foregroundStyle(.secondary)
                            TextField("Название соревнования", text: $competition)
                                .focused($focus, equals: .competition)
                        }
                    }

                    saveButton

                    if let notice = normatives.staleNotice {
                        Text(notice).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .padding(16)
                .padding(.bottom, 16)
            }
            .scrollDismissesKeyboard(.interactively)
            .background { AuroraBackground() }
            .navigationTitle(isEditing ? "Изменить заплыв" : "Новый заплыв")
            .onAppear { prefillIfNeeded() }
            .toolbar {
                if isEditing {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Отмена") { dismiss() }
                    }
                }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Готово") { focus = nil }
                }
            }
            .onChange(of: stroke) { _ in normalizeDistance() }
            .onChange(of: pool) { _ in normalizeDistance() }
            .onChange(of: minutesText) { value in
                let digits = value.filter { $0.isNumber }
                if digits != value { minutesText = digits }
            }
            .onChange(of: secondsText) { value in
                let digits = String(value.filter { $0.isNumber }.prefix(2))
                if digits != value { secondsText = digits }
                // Две цифры секунд введены — переходим к сотым
                if digits.count == 2 && focus == .seconds { focus = .hundredths }
            }
            .onChange(of: hundredthsText) { value in
                let digits = String(value.filter { $0.isNumber }.prefix(2))
                if digits != value { hundredthsText = digits }
            }
            .sheet(isPresented: $showAgeSheet) {
                AgeSheet { value in
                    age = value
                    showAgeSheet = false
                    // Ждём закрытия окна возраста, чтобы второе окно показалось корректно
                    Task {
                        try? await Task.sleep(nanoseconds: 450_000_000)
                        commitSave()
                    }
                }
            }
            .sheet(item: $saved, onDismiss: { onFinished() }) { info in
                SavedSheet(info: info)
            }
        }
    }

    // MARK: Части экрана

    /// Живой предпросмотр: очки и разряд пересчитываются по мере ввода.
    private var preview: some View {
        let points = draft.flatMap { FinaPoints.shared.points(for: $0) }
        let outcome = draft.flatMap { evaluate($0, normatives: normatives, age: age) }

        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("\(distance) м · \(stroke.title)")
                    .font(.system(.headline, design: .rounded))
                Spacer()
                Pill(text: "бассейн \(pool.rawValue) м", onGradient: true)
            }
            Text(timeMs.map { TimeParser.format(ms: $0) } ?? "0,00")
                .font(.system(size: 52, weight: .heavy, design: .rounded))
                .monospacedDigit()
                .opacity(timeMs == nil ? 0.5 : 1)
                .contentTransition(.numericText())
            HStack(spacing: 10) {
                Label(points.map { "\($0) очков" } ?? "— очков", systemImage: "bolt.fill")
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                Spacer()
                if timeMs != nil { RankBadge(rank: outcome?.achieved) }
            }
            if let gap = outcome?.gapText {
                Text(gap.prefix(1).uppercased() + gap.dropFirst())
                    .font(.footnote)
                    .opacity(0.9)
            } else if timeMs != nil && outcome == nil {
                Text("Норматив не установлен")
                    .font(.footnote)
                    .opacity(0.9)
            }
        }
        .foregroundStyle(.white)
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(stroke.gradient, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.white.opacity(0.4), lineWidth: 1)
        }
        .shadow(color: stroke.tint.opacity(0.4), radius: 18, y: 10)
        .animation(.spring(response: 0.4, dampingFraction: 0.8), value: timeMs)
        .animation(.easeInOut(duration: 0.3), value: stroke)
    }

    private var timeInput: some View {
        HStack(alignment: .center, spacing: 6) {
            timeField(placeholder: "0", text: $minutesText, unit: "мин", field: .minutes, keyboard: .numberPad)
            Text(":")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundStyle(.secondary)
                .padding(.bottom, 18)
            timeField(placeholder: "00", text: $secondsText, unit: "сек", field: .seconds, keyboard: .numberPad)
            Text(",")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundStyle(.secondary)
                .padding(.bottom, 18)
            timeField(placeholder: "00", text: $hundredthsText, unit: "сотые", field: .hundredths, keyboard: .numberPad)
        }
    }

    private func timeField(placeholder: String, text: Binding<String>, unit: String,
                           field: Field, keyboard: UIKeyboardType) -> some View {
        VStack(spacing: 2) {
            TextField(placeholder, text: text)
                .keyboardType(keyboard)
                .focused($focus, equals: field)
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .padding(.vertical, 6)
                .background(Color.secondary.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            Text(unit).font(.caption).foregroundStyle(.secondary)
        }
    }

    private var saveButton: some View {
        Button(action: saveTapped) {
            Label(isEditing ? "Сохранить изменения" : "Сохранить результат", systemImage: "checkmark.circle.fill")
                .font(.system(.headline, design: .rounded))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .foregroundStyle(.white)
                .background(Theme.accentGradient, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .shadow(color: Theme.accent.opacity(0.45), radius: 16, y: 8)
        }
        .buttonStyle(PressableStyle())
        .disabled(timeMs == nil)
        .opacity(timeMs == nil ? 0.45 : 1)
    }

    @ViewBuilder
    private func card<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    // MARK: Логика

    /// Если выбранной дистанции нет для нового способа или бассейна — берём первую доступную.
    private func normalizeDistance() {
        if !distances.contains(distance), let first = distances.first {
            withAnimation { distance = first }
        }
    }

    private func saveTapped() {
        guard timeMs != nil else { return }
        focus = nil
        // Возраст спрашиваем один раз, перед первым сохранением
        if age == 0 {
            showAgeSheet = true
        } else {
            commitSave()
        }
    }

    /// Заполняет поля данными правимого результата (один раз при открытии).
    private func prefillIfNeeded() {
        guard let editing, !didPrefill else { return }
        didPrefill = true
        editGender = editing.gender
        pool = editing.pool
        stroke = editing.stroke
        distance = editing.distance
        let total = editing.timeMs / 10          // сотые доли секунды
        let minutes = total / 6000
        minutesText = minutes > 0 ? String(minutes) : ""
        secondsText = String((total / 100) % 60)
        hundredthsText = String(format: "%02d", total % 100)
        date = editing.date
        competition = editing.competition
    }

    private func commitSave() {
        guard let timeMs else { return }
        if let editing {
            var updated = editing
            updated.distance = distance
            updated.stroke = stroke
            updated.pool = pool
            updated.timeMs = timeMs
            updated.date = date
            updated.competition = competition.trimmingCharacters(in: .whitespaces)
            updated.gender = gender.wrappedValue
            store.update(updated)
            Haptics.success()
            dismiss()
            onFinished()
            return
        }
        let result = SwimResult(distance: distance, stroke: stroke, pool: pool, timeMs: timeMs, date: date,
                                competition: competition.trimmingCharacters(in: .whitespaces),
                                gender: gender.wrappedValue)
        // Лучшее время до сохранения — чтобы понять, рекорд ли это
        let previous = store.results.filter { $0.discipline == result.discipline }.map(\.timeMs).min()
        store.add(result)

        let info = SavedInfo(result: result,
                             points: FinaPoints.shared.points(for: result),
                             outcome: evaluate(result, normatives: normatives, age: age),
                             previousBestMs: previous)
        Haptics.success()
        saved = info

        minutesText = ""
        secondsText = ""
        hundredthsText = ""
    }
}
