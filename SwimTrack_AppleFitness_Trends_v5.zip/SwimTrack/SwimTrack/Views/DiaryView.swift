import SwiftUI

/// Вкладка «Дневник»: все данные пловца на одном экране.
@MainActor
struct DiaryView: View {
    @EnvironmentObject private var normatives: NormativeStore
    @EnvironmentObject private var store: ResultsStore
    @AppStorage("swimtrack.age") private var age: Int = 0

    let onAdd: () -> Void

    @State private var selectedKey: DisciplineKey?
    @State private var detail: SwimResult?
    @State private var onlySelected = false
    @State private var isImportingWorkouts = false
    @State private var importMessage: String?
    /// Тренд считается один раз при изменении данных, а не при каждой перерисовке списка.
    @State private var trend: WorkoutTrend = .empty
    @State private var distanceProgress: [DistanceProgress] = []
    @State private var strokeFilter: Stroke?
    @State private var showWorkoutLinks = false

    private struct StatsKey: Equatable {
        let revision: Int
        let stroke: Stroke?
    }

    /// Способы, которые есть среди тренировок (для фильтра динамики).
    private var workoutStrokes: [Stroke] {
        let present = Set(store.workouts.compactMap(\.effectiveStroke))
        return Stroke.allCases.filter { present.contains($0) }
    }

    private var unlinkedCount: Int { store.workouts.filter { $0.effectiveStroke == nil }.count }

    // MARK: Данные

    private var summaries: [DisciplineSummary] { DiaryStats.summaries(results: store.results) }

    /// Выбранная дисциплина (если выбор пропал после удаления — первая в списке).
    private var active: DisciplineSummary? {
        summaries.first { $0.key == selectedKey } ?? summaries.first
    }

    private var bestByPoints: ScoredResult? {
        DiaryStats.scored(store.results).max { $0.points < $1.points }
    }

    private var topRank: Rank? {
        store.results
            .compactMap { outcome($0)?.achieved }
            .min { (Rank.allCases.firstIndex(of: $0) ?? 99) < (Rank.allCases.firstIndex(of: $1) ?? 99) }
    }

    private var cardModels: [DisciplineCardModel] {
        summaries.map { s in
            DisciplineCardModel(summary: s,
                                rank: outcome(s.best)?.achieved,
                                points: FinaPoints.shared.points(for: s.best))
        }
    }

    private var history: [SwimResult] {
        let all = store.results.sorted { $0.date > $1.date }
        guard onlySelected, let key = active?.key else { return all }
        return all.filter { $0.discipline == key }
    }

    private func outcome(_ result: SwimResult) -> RankOutcome? {
        evaluate(result, normatives: normatives, age: age)
    }

    // MARK: Экран

    var body: some View {
        NavigationStack {
            List {
                if store.results.isEmpty && store.workouts.isEmpty {
                    EmptyDiaryCard(onAdd: onAdd).diaryRow()
                } else {
                    if !store.results.isEmpty {
                    if let top = bestByPoints {
                        HeroCard(scored: top, rank: outcome(top.result)?.achieved)
                            .diaryRow(top: 4, bottom: 8)
                    }

                    StatsRow(total: store.results.count, disciplines: summaries.count, topRank: topRank)
                        .diaryRow()

                    DisciplineCarousel(models: cardModels, selected: active?.key) { key in
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { selectedKey = key }
                    }
                    .diaryRow(top: 8, bottom: 4, horizontal: 0)

                    if let s = active {
                        ProgressCard(title: "\(s.key.title) · \(s.key.pool.title)",
                                     tint: s.key.stroke.tint,
                                     scored: DiaryStats.scored(s.results))
                            .diaryRow()
                        goalView(for: s).diaryRow()
                    }

                    historyHeader.diaryRow(top: 14, bottom: 2)

                    ForEach(Array(history.enumerated()), id: \.element.id) { index, result in
                        ResultRow(result: result,
                                  rank: outcome(result)?.achieved,
                                  points: FinaPoints.shared.points(for: result),
                                  isBest: DiaryStats.isPersonalBest(result, in: store.results),
                                  showMonth: index == 0 || !Calendar.current.isDate(history[index - 1].date,
                                                                                     equalTo: result.date,
                                                                                     toGranularity: .month),
                                  onTap: { detail = result })
                            .diaryRow(top: 4, bottom: 4)
                            // Свайп влево — удалить
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                Button(role: .destructive) {
                                    remove(result)
                                } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                    }

                    Color.clear.frame(height: 24).diaryRow(top: 0, bottom: 0)
                    }

                    if !store.workouts.isEmpty {
                        DistanceProgressCard(items: distanceProgress)
                            .diaryRow(top: 14, bottom: 8)
                        if !workoutStrokes.isEmpty { strokeFilterRow.diaryRow(top: 8, bottom: 0) }
                        WorkoutTrendCard(trend: trend)
                            .diaryRow(top: 8, bottom: 8)
                        linkWorkoutsButton.diaryRow(top: 4, bottom: 8)
                        Color.clear.frame(height: 24).diaryRow(top: 0, bottom: 0)
                    }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background { AuroraBackground() }
            .navigationTitle("Твой дневник")
            .task(id: StatsKey(revision: store.workoutsRevision, stroke: strokeFilter)) {
                let filtered = strokeFilter.map { s in store.workouts.filter { $0.effectiveStroke == s } } ?? store.workouts
                trend = WorkoutStats.trend(workouts: filtered)
                distanceProgress = WorkoutStats.distanceProgress(workouts: store.workouts)
            }
            .sheet(isPresented: $showWorkoutLinks) { WorkoutsLinkView() }
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button {
                        Task { await importAppleWorkouts() }
                    } label: {
                        if isImportingWorkouts { ProgressView() }
                        else { Image(systemName: "applewatch") }
                    }
                    .disabled(isImportingWorkouts)
                    .accessibilityLabel("Импортировать из Apple Fitness")
                    Button(action: onAdd) { Image(systemName: "plus") }
                }
            }
            .alert("Apple Fitness", isPresented: Binding(
                get: { importMessage != nil }, set: { if !$0 { importMessage = nil } }
            )) {
                Button("Понятно", role: .cancel) { importMessage = nil }
            } message: {
                Text(importMessage ?? "")
            }
            .sheet(item: $detail) { result in
                ResultDetailView(result: result,
                                 isBest: DiaryStats.isPersonalBest(result, in: store.results),
                                 onDelete: { remove(result) })
            }
        }
    }

    // MARK: Части экрана

    private var strokeFilterRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Button { Haptics.tap(); strokeFilter = nil } label: {
                    Pill(text: "Все стили", tint: strokeFilter == nil ? Theme.exercise : .secondary)
                }
                .buttonStyle(PressableStyle())
                ForEach(workoutStrokes) { stroke in
                    Button { Haptics.tap(); strokeFilter = stroke } label: {
                        Pill(text: stroke.title, tint: strokeFilter == stroke ? Theme.exercise : .secondary)
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }

    private var linkWorkoutsButton: some View {
        Button { Haptics.tap(); showWorkoutLinks = true } label: {
            HStack(spacing: 10) {
                Image(systemName: "link").foregroundStyle(Theme.stand)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Привязать тренировки к стилю")
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    Text(unlinkedCount > 0 ? "Без стиля: \(unlinkedCount) из \(store.workouts.count)"
                                           : "Все \(store.workouts.count) тренировок привязаны")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(radius: 20)
        }
        .buttonStyle(PressableStyle())
    }

    private var historyHeader: some View {
        HStack(alignment: .bottom) {
            SectionTitle(title: "История", subtitle: "\(history.count) из \(store.results.count) заплывов")
            Spacer()
            if let key = active?.key {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { onlySelected.toggle() }
                } label: {
                    Pill(text: onlySelected ? "Только \(key.distance) м" : "Все дисциплины",
                         systemImage: "line.3.horizontal.decrease.circle",
                         tint: Theme.accent)
                }
                .buttonStyle(PressableStyle())
            }
        }
        .padding(.horizontal, 4)
    }

    @ViewBuilder
    private func goalView(for s: DisciplineSummary) -> some View {
        let n = normatives.normative(distance: s.key.distance, stroke: s.key.stroke,
                                     pool: s.key.pool, gender: s.best.gender)
        if let n {
            let o = RankCalculator.evaluate(timeMs: s.best.timeMs, normative: n, age: age > 0 ? age : nil)
            GoalCard(tint: s.key.stroke.tint,
                     current: o.achieved,
                     next: o.next,
                     gapText: o.gapText,
                     progress: DiaryStats.progress(timeMs: s.best.timeMs, normative: n, outcome: o),
                     blocked: o.blockedByAge,
                     noNormative: false)
        } else {
            GoalCard(tint: s.key.stroke.tint, current: nil, next: nil, gapText: nil,
                     progress: 0, blocked: nil, noNormative: true)
        }
    }

    private func importAppleWorkouts() async {
        guard !isImportingWorkouts else { return }
        isImportingWorkouts = true
        defer { isImportingWorkouts = false }
        do {
            let imported = try await HealthKitImportService.shared.importSwimmingWorkouts()
            let added = store.importWorkouts(imported)
            if imported.isEmpty {
                importMessage = "Тренировки плавания не найдены. Проверь, что они сохранены в Apple Health и SwimTrack разрешён доступ к данным «Здоровье» в настройках iPhone."
            } else if added == 0 {
                importMessage = "Все тренировки уже импортированы. Новых записей нет."
            } else {
                importMessage = "Добавлено тренировок: \(added). Всего найдено: \(imported.count). Повторные записи не дублируются."
            }
        } catch {
            importMessage = error.localizedDescription
        }
    }

    private func remove(_ result: SwimResult) {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            store.delete(ids: [result.id])
        }
        if detail?.id == result.id { detail = nil }
    }
}
