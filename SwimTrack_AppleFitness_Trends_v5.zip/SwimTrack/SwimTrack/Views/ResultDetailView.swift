import SwiftUI

/// Подробности заплыва: время, очки FINA в виде кольца и лестница разрядов.
@MainActor
struct ResultDetailView: View {
    let result: SwimResult
    let isBest: Bool
    let onDelete: () -> Void

    @EnvironmentObject private var normatives: NormativeStore
    @AppStorage("swimtrack.age") private var age: Int = 0
    @Environment(\.dismiss) private var dismiss

    @State private var confirmDelete = false
    @State private var showEdit = false
    @State private var ring: Double = 0

    private var normative: Normative? {
        normatives.normative(distance: result.distance, stroke: result.stroke,
                             pool: result.pool, gender: result.gender)
    }

    private var outcome: RankOutcome? {
        normative.map { RankCalculator.evaluate(timeMs: result.timeMs, normative: $0, age: age > 0 ? age : nil) }
    }

    private var points: Int? { FinaPoints.shared.points(for: result) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    if let points { pointsCard(points) }
                    ladder
                    Button {
                        Haptics.tap()
                        showEdit = true
                    } label: {
                        Label("Изменить результат", systemImage: "pencil")
                            .font(.system(.body, design: .rounded).weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .glassCard(radius: 22)
                    }
                    .buttonStyle(PressableStyle())
                    Button(role: .destructive) {
                        confirmDelete = true
                    } label: {
                        Label("Удалить результат", systemImage: "trash")
                            .font(.system(.body, design: .rounded).weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .glassCard(radius: 22)
                    }
                    .buttonStyle(PressableStyle())
                }
                .padding(16)
            }
            .background { AuroraBackground() }
            .navigationTitle("Заплыв")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
            .sheet(isPresented: $showEdit) {
                // После сохранения закрываем и окно подробностей: в нём остались бы старые данные
                AddResultView(editing: result, onFinished: { dismiss() })
            }
            .confirmationDialog("Удалить этот результат?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) {
                    onDelete()
                    dismiss()
                }
                Button("Отмена", role: .cancel) {}
            }
        }
        .presentationDetents([.large])
    }

    // MARK: Шапка

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Pill(text: "бассейн \(result.pool.rawValue) м", onGradient: true)
                if isBest { Pill(text: "Личный рекорд", systemImage: "star.fill", onGradient: true) }
                Spacer()
                RankBadge(rank: outcome?.achieved)
            }
            Text(result.eventTitle)
                .font(.system(.headline, design: .rounded))
                .opacity(0.95)
            Text(TimeParser.format(ms: result.timeMs))
                .font(.system(size: 60, weight: .heavy, design: .rounded))
                .monospacedDigit()
            HStack(spacing: 4) {
                Text(result.date, format: .dateTime.day().month(.wide).year())
                if !result.competition.isEmpty { Text("· \(result.competition)") }
            }
            .font(.subheadline)
            .opacity(0.9)
        }
        .foregroundStyle(.white)
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(result.stroke.gradient, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.white.opacity(0.4), lineWidth: 1)
        }
        .shadow(color: result.stroke.tint.opacity(0.4), radius: 18, y: 10)
    }

    // MARK: Очки

    private func pointsCard(_ points: Int) -> some View {
        HStack(spacing: 18) {
            ZStack {
                Circle().stroke(Color.secondary.opacity(0.18), lineWidth: 14)
                Circle()
                    .trim(from: 0, to: ring)
                    .stroke(Theme.accentGradient, style: StrokeStyle(lineWidth: 14, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text("\(points)")
                        .font(.system(size: 34, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                    Text("очков")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: 130, height: 130)

            VStack(alignment: .leading, spacing: 6) {
                Text("Очки FINA")
                    .font(.system(.headline, design: .rounded))
                Text("Базовое время World Aquatics для этой дисциплины даёт 1000 очков. Кольцо заполняется до 1000.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28)
        .onAppear {
            withAnimation(.spring(response: 1.1, dampingFraction: 0.8).delay(0.15)) {
                ring = min(Double(points) / 1000, 1)
            }
        }
    }

    // MARK: Лестница разрядов

    @ViewBuilder
    private var ladder: some View {
        VStack(alignment: .leading, spacing: 6) {
            SectionTitle(title: "Лестница разрядов", subtitle: "Нормативы для этой дисциплины")
                .padding(.bottom, 6)

            if let normative {
                ForEach(Rank.allCases, id: \.self) { rank in
                    ladderRow(rank, normative: normative)
                }
                if let gap = outcome?.gapText {
                    Text(gap.prefix(1).uppercased() + gap.dropFirst())
                        .font(.subheadline.weight(.semibold))
                        .padding(.top, 8)
                }
            } else {
                Text("Норматив не установлен: для этой дисциплины в таблице нет данных.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 28)
    }

    private func ladderRow(_ rank: Rank, normative: Normative) -> some View {
        let norm = normative.ranks[rank]
        let reached = norm.map { result.timeMs <= $0 } ?? false
        let lockedByAge = (rank.minimumAge ?? 0) > (age > 0 ? age : Int.max)
        let isCurrent = outcome?.achieved == rank
        let isNext = outcome?.next == rank

        return HStack(spacing: 12) {
            ZStack {
                Circle().fill(reached && !lockedByAge ? AnyShapeStyle(rank.gradient)
                                                      : AnyShapeStyle(Color.secondary.opacity(0.18)))
                Image(systemName: lockedByAge ? "lock.fill" : (reached ? "checkmark" : "circle"))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(reached && !lockedByAge ? Color.white : Color.secondary)
            }
            .frame(width: 28, height: 28)

            Text(rank.rawValue)
                .font(.system(.body, design: .rounded).weight(.bold))
            Spacer()
            if isNext, let norm {
                Text("−\(TimeParser.secondsText(ms: result.timeMs - norm)) с")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Color.orange)
            }
            Text(norm.map { TimeParser.format(ms: $0) } ?? "—")
                .font(.system(.body, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(reached ? Color.primary : Color.secondary)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(isCurrent ? rank.tint.opacity(0.18) : Color.clear,
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
