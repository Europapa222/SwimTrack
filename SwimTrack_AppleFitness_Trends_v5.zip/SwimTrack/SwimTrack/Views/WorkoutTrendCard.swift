import SwiftUI
import Charts

// Карточка «Динамика» по тренировкам Apple Fitness: на сколько пловец стал быстрее или медленнее.
// Принимает готовый WorkoutTrend, поэтому ничего не считает при отрисовке.

enum PaceFormat {
    /// 92,4 → «1:32»
    static func clock(_ seconds: Double) -> String {
        let total = Int(seconds.rounded())
        return String(format: "%d:%02d", total / 60, total % 60)
    }

    /// Модуль разницы: «3 с» или «1:05».
    static func gap(_ seconds: Double) -> String {
        let s = abs(seconds)
        return s < 60 ? String(format: "%.1f с", s).replacingOccurrences(of: ".", with: ",") : clock(s)
    }
}

struct WorkoutTrendCard: View {
    let trend: WorkoutTrend

    // Видимый отрезок времени на графике (nil = весь период), выбранная точка и база жестов.
    @State private var domain: ClosedRange<Date>?
    @State private var selected: PacePoint?
    @State private var gestureBase: ClosedRange<Date>?

    private var tint: Color {
        switch trend.verdict {
        case .improving: return Theme.exercise
        case .declining: return Theme.move
        case .stable: return Theme.stand
        case .notEnough: return .secondary
        }
    }

    private var icon: String {
        switch trend.verdict {
        case .improving: return "arrow.up.right"
        case .declining: return "arrow.down.right"
        case .stable: return "equal"
        case .notEnough: return "hourglass"
        }
    }

    private var title: String {
        switch trend.verdict {
        case .improving: return "Ты быстрее"
        case .declining: return "Темп просел"
        case .stable: return "Без изменений"
        case .notEnough: return "Мало данных"
        }
    }

    private var subtitle: String {
        guard let pace = trend.pace else {
            return "Для сравнения нужно минимум 4 тренировки от 200 м с дистанцией и временем."
        }
        let n = trend.groupSize
        switch trend.verdict {
        case .stable:
            return "Темп за последние \(n) тренировок почти такой же, как за предыдущие \(n): \(PaceFormat.clock(pace.current)) на 100 м."
        case .improving:
            return "на \(PaceFormat.gap(pace.delta)) на 100 м быстрее (\(percentText(pace.percent))), чем в предыдущих \(n) тренировках."
        default:
            return "на \(PaceFormat.gap(pace.delta)) на 100 м медленнее (\(percentText(pace.percent))), чем в предыдущих \(n) тренировках."
        }
    }

    private func percentText(_ value: Double) -> String {
        String(format: "%.1f%%", abs(value)).replacingOccurrences(of: ".", with: ",")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Динамика · Apple Fitness")
                        .font(.system(.footnote, design: .rounded).weight(.semibold))
                        .foregroundStyle(.secondary)
                    HStack(spacing: 8) {
                        Image(systemName: icon).font(.title2.weight(.bold))
                        Text(title).font(.system(.title2, design: .rounded).weight(.bold))
                    }
                    .foregroundStyle(tint)
                }
                Spacer()
                if let pace = trend.pace {
                    VStack(alignment: .trailing, spacing: 0) {
                        Text(PaceFormat.clock(pace.current))
                            .font(.system(.title2, design: .rounded).weight(.bold)).monospacedDigit()
                        Text("/100 м сейчас").font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }

            Text(subtitle).font(.footnote).foregroundStyle(.secondary)

            if trend.points.count >= 2 { chart }

            HStack(spacing: 10) {
                tile(title: "Темп", change: trend.pace, lowerIsBetter: true,
                     valueText: { PaceFormat.clock($0) }, deltaText: { PaceFormat.gap($0) })
                tile(title: "SWOLF", change: trend.swolf, lowerIsBetter: true,
                     valueText: { String(Int($0.rounded())) }, deltaText: { String(Int(abs($0).rounded())) })
                tile(title: "Объём/нед", change: trend.volume, lowerIsBetter: false,
                     valueText: { "\(Int($0.rounded())) м" }, deltaText: { "\(Int(abs($0).rounded())) м" })
            }

            Text("Темп = время тренировки ÷ дистанция, отдых между отрезками входит в него. Тренировки не влияют на очки FINA и разряды.")
                .font(.caption2).foregroundStyle(.tertiary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 24, tint: tint)
    }

    // MARK: График

    private var fullRange: ClosedRange<Date>? {
        guard let first = trend.points.first?.date, let last = trend.points.last?.date else { return nil }
        let pad = max(last.timeIntervalSince(first) * 0.04, 86_400)
        return first.addingTimeInterval(-pad)...last.addingTimeInterval(pad)
    }

    private var visible: ClosedRange<Date>? { domain ?? fullRange }

    /// Нормализует отрезок: не уже 3 дней, не шире всего периода и не выходит за его границы.
    private func clamp(start: Date, span: TimeInterval) -> ClosedRange<Date>? {
        guard let full = fullRange else { return nil }
        let fullSpan = full.upperBound.timeIntervalSince(full.lowerBound)
        let s = min(max(span, 3 * 86_400), fullSpan)
        var lo = start
        if lo < full.lowerBound { lo = full.lowerBound }
        if lo.addingTimeInterval(s) > full.upperBound { lo = full.upperBound.addingTimeInterval(-s) }
        return lo...lo.addingTimeInterval(s)
    }

    private func setLast(days: Int?) {
        Haptics.tap()
        selected = nil
        guard let days, let full = fullRange else { domain = nil; return }
        let end = full.upperBound
        domain = clamp(start: end.addingTimeInterval(-Double(days) * 86_400), span: Double(days) * 86_400)
    }

    private var chart: some View {
        let range = visible
        let pts = trend.points.filter { range?.contains($0.date) ?? true }
        let line = trend.smoothed.filter { range?.contains($0.date) ?? true }
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                ForEach([("Месяц", 30), ("3 мес.", 90), ("Полгода", 180)], id: \.1) { item in
                    Button { setLast(days: item.1) } label: { Pill(text: item.0, tint: Theme.stand) }
                        .buttonStyle(PressableStyle())
                }
                Button { setLast(days: nil) } label: { Pill(text: "Всё", tint: Theme.exercise) }
                    .buttonStyle(PressableStyle())
                Spacer()
            }
            Chart {
                ForEach(pts) { p in
                    PointMark(x: .value("Дата", p.date), y: .value("Темп", p.pace))
                        .foregroundStyle(Theme.stand.opacity(0.75))
                        .symbolSize(selected?.id == p.id ? 110 : 44)
                }
                ForEach(line) { p in
                    LineMark(x: .value("Дата", p.date), y: .value("Среднее", p.pace))
                        .foregroundStyle(tint)
                        .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round))
                        .interpolationMethod(.catmullRom)
                }
                if let best = trend.bestPace, range?.contains(best.date) ?? true {
                    PointMark(x: .value("Дата", best.date), y: .value("Темп", best.pace))
                        .foregroundStyle(Color(hex: 0xFFD76A))
                        .symbol(.diamond)
                        .symbolSize(90)
                }
                if let sel = selected {
                    RuleMark(x: .value("Дата", sel.date))
                        .foregroundStyle(Color.white.opacity(0.35))
                        .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3]))
                }
            }
            // Быстрее (меньший темп) — выше
            .chartYScale(domain: .automatic(includesZero: false, reversed: true))
            .chartXScale(domain: range ?? Date()...Date().addingTimeInterval(1))
            .chartYAxis {
                AxisMarks(position: .leading) { value in
                    AxisGridLine().foregroundStyle(Color.white.opacity(0.08))
                    AxisValueLabel {
                        if let v = value.as(Double.self) { Text(PaceFormat.clock(v)).font(.caption2) }
                    }
                }
            }
            .chartXAxis {
                AxisMarks(values: .automatic(desiredCount: 4)) { _ in
                    AxisGridLine().foregroundStyle(Color.white.opacity(0.05))
                    AxisValueLabel(format: .dateTime.day().month(.abbreviated), centered: false)
                }
            }
            .chartOverlay { proxy in
                GeometryReader { geo in
                    Rectangle().fill(Color.clear).contentShape(Rectangle())
                        // Касание — показать ближайшую тренировку
                        .gesture(SpatialTapGesture().onEnded { value in
                            let x = value.location.x - geo[proxy.plotAreaFrame].origin.x
                            guard let date: Date = proxy.value(atX: x),
                                  let nearest = pts.min(by: { abs($0.date.timeIntervalSince(date)) < abs($1.date.timeIntervalSince(date)) })
                            else { return }
                            Haptics.tap()
                            selected = (selected?.id == nearest.id) ? nil : nearest
                        })
                        // Щипок — приблизить/отдалить
                        .simultaneousGesture(MagnificationGesture()
                            .onChanged { scale in
                                guard let base = gestureBase ?? visible else { return }
                                gestureBase = base
                                let span = base.upperBound.timeIntervalSince(base.lowerBound)
                                let mid = base.lowerBound.addingTimeInterval(span / 2)
                                let newSpan = span / Double(max(scale, 0.1))
                                domain = clamp(start: mid.addingTimeInterval(-newSpan / 2), span: newSpan)
                            }
                            .onEnded { _ in gestureBase = nil })
                        // Перетаскивание — двигать по времени
                        .simultaneousGesture(DragGesture(minimumDistance: 12)
                            .onChanged { value in
                                guard let base = gestureBase ?? visible else { return }
                                gestureBase = base
                                let span = base.upperBound.timeIntervalSince(base.lowerBound)
                                let width = max(geo[proxy.plotAreaFrame].width, 1)
                                let shift = -Double(value.translation.width / width) * span
                                domain = clamp(start: base.lowerBound.addingTimeInterval(shift), span: span)
                            }
                            .onEnded { _ in gestureBase = nil })
                }
            }
            .frame(height: 230)
            .clipped()

            if let sel = selected {
                HStack(spacing: 8) {
                    Text(sel.date, format: .dateTime.day().month(.wide).year())
                    Spacer()
                    Text("\(PaceFormat.clock(sel.pace)) /100 м · \(Int(sel.distance.rounded())) м").monospacedDigit()
                }
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(Theme.stand)
            } else {
                Text("Щипок — масштаб, смахивание — сдвиг, касание точки — детали. Ромб — лучший темп.")
                    .font(.caption2).foregroundStyle(.tertiary)
            }
        }
    }

    // MARK: Плитка показателя

    private func tile(title: String, change: MetricChange?, lowerIsBetter: Bool,
                      valueText: (Double) -> String, deltaText: (Double) -> String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption2).foregroundStyle(.secondary)
            if let change {
                Text(valueText(change.current))
                    .font(.system(.subheadline, design: .rounded).weight(.bold)).monospacedDigit()
                let better = lowerIsBetter ? change.delta < 0 : change.delta > 0
                let same = abs(change.percent) < WorkoutStats.stablePercent
                HStack(spacing: 3) {
                    Image(systemName: same ? "equal" : (change.delta > 0 ? "arrow.up" : "arrow.down"))
                    Text(same ? "без изм." : deltaText(change.delta))
                }
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(same ? Theme.stand : (better ? Theme.exercise : Theme.move))
            } else {
                Text("—").font(.system(.subheadline, design: .rounded).weight(.bold))
                Text("нет данных").font(.system(size: 11)).foregroundStyle(.tertiary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.white.opacity(0.06)))
    }
}

// MARK: - Карточка «Прогресс на дистанции»

struct DistanceProgressCard: View {
    let items: [DistanceProgress]

    @State private var chosen: String?
    @State private var selected: DistancePoint?

    private var current: DistanceProgress? {
        items.first { $0.id == chosen } ?? items.first
    }

    private func tint(_ v: TrendVerdict) -> Color {
        switch v {
        case .improving: return Theme.exercise
        case .declining: return Theme.move
        default: return Theme.stand
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Прогресс на дистанции")
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)

            if let item = current {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(items) { it in
                            Button {
                                Haptics.tap()
                                selected = nil
                                chosen = it.id
                            } label: {
                                Pill(text: "\(it.title) · \(it.points.count)",
                                     tint: it.id == item.id ? Theme.exercise : .secondary)
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }
                }

                header(item)
                chart(item)
                footer(item)
            } else {
                Text("Нужно минимум две тренировки примерно одной длины (например, 500 м и 520 м), чтобы сравнить время.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 24, tint: current.map { tint($0.verdict) })
    }

    private func header(_ item: DistanceProgress) -> some View {
        let c = item.change
        let color = tint(item.verdict)
        let word: String
        switch item.verdict {
        case .improving: word = "быстрее на \(PaceFormat.gap(c.delta))"
        case .declining: word = "медленнее на \(PaceFormat.gap(c.delta))"
        default: word = "без изменений"
        }
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(PaceFormat.clock(c.previous))
                    .font(.system(.title3, design: .rounded).weight(.semibold)).foregroundStyle(.secondary)
                Image(systemName: "arrow.right").foregroundStyle(.secondary)
                Text(PaceFormat.clock(c.current))
                    .font(.system(.largeTitle, design: .rounded).weight(.bold)).foregroundStyle(color)
            }
            .monospacedDigit()
            HStack(spacing: 6) {
                Image(systemName: item.verdict == .improving ? "arrow.up.right"
                      : item.verdict == .declining ? "arrow.down.right" : "equal")
                Text("\(item.title): \(word)" + (item.verdict == .stable ? "" :
                     " (\(String(format: "%.0f", abs(c.percent)))%)"))
            }
            .font(.system(.subheadline, design: .rounded).weight(.semibold))
            .foregroundStyle(color)
        }
    }

    private func chart(_ item: DistanceProgress) -> some View {
        let color = tint(item.verdict)
        return Chart {
            ForEach(item.points) { p in
                LineMark(x: .value("Дата", p.date), y: .value("Время", p.seconds))
                    .foregroundStyle(color.opacity(0.8))
                    .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                    .interpolationMethod(.monotone)
                PointMark(x: .value("Дата", p.date), y: .value("Время", p.seconds))
                    .foregroundStyle(p.id == item.best.id ? Color(hex: 0xFFD76A) : color)
                    .symbol(p.id == item.best.id ? .diamond : .circle)
                    .symbolSize(selected?.id == p.id ? 120 : 55)
            }
            if let sel = selected {
                RuleMark(x: .value("Дата", sel.date))
                    .foregroundStyle(Color.white.opacity(0.35))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3]))
            }
        }
        .chartYScale(domain: .automatic(includesZero: false, reversed: true))
        .chartYAxis {
            AxisMarks(position: .leading) { value in
                AxisGridLine().foregroundStyle(Color.white.opacity(0.08))
                AxisValueLabel {
                    if let v = value.as(Double.self) { Text(PaceFormat.clock(v)).font(.caption2) }
                }
            }
        }
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 4)) { _ in
                AxisValueLabel(format: .dateTime.day().month(.abbreviated), centered: false)
            }
        }
        .chartOverlay { proxy in
            GeometryReader { geo in
                Rectangle().fill(Color.clear).contentShape(Rectangle())
                    .gesture(SpatialTapGesture().onEnded { value in
                        let x = value.location.x - geo[proxy.plotAreaFrame].origin.x
                        guard let date: Date = proxy.value(atX: x),
                              let nearest = item.points.min(by: {
                                  abs($0.date.timeIntervalSince(date)) < abs($1.date.timeIntervalSince(date)) })
                        else { return }
                        Haptics.tap()
                        selected = (selected?.id == nearest.id) ? nil : nearest
                    })
            }
        }
        .frame(height: 170)
    }

    private func footer(_ item: DistanceProgress) -> some View {
        Group {
            if let sel = selected {
                HStack {
                    Text(sel.date, format: .dateTime.day().month(.wide).year())
                    Spacer()
                    Text("\(PaceFormat.clock(sel.seconds)) на \(item.distance) м · факт \(Int(sel.actualDistance.rounded())) м")
                        .monospacedDigit()
                }
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(Theme.stand)
            } else {
                Text("Слева — время в начале, справа — сейчас (среднее первых и последних тренировок). Если дистанция отличалась, время пересчитано на \(item.distance) м. Ромб — лучшее время.")
                    .font(.caption2).foregroundStyle(.tertiary)
            }
        }
    }
}
