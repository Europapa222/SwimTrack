import SwiftUI

/// Список тренировок Apple Fitness с привязкой к способу плавания и длине бассейна.
/// Открывается отдельным окном (List ленивый), поэтому большое число тренировок главный экран не тормозит.
@MainActor
struct WorkoutsLinkView: View {
    @EnvironmentObject private var store: ResultsStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Стиль и бассейн из Apple Health подставляются сами, если в тренировке один стиль. Если нет — выбери вручную. Привязка нужна, чтобы «Прогресс на дистанции» сравнивал только одинаковое: вольный стиль с вольным, 25 м с 25 м.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .listRowBackground(Color.clear)
                }
                ForEach(store.workouts) { workout in
                    WorkoutLinkRow(workout: workout)
                        .listRowBackground(Color.clear)
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background { AuroraBackground() }
            .navigationTitle("Тренировки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Menu {
                        ForEach(Stroke.allCases) { stroke in
                            Button(stroke.title) {
                                Haptics.tap()
                                store.assignStrokeToUnlinked(stroke)
                            }
                        }
                    } label: {
                        Label("Всем без стиля", systemImage: "wand.and.stars")
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }
}

private struct WorkoutLinkRow: View {
    let workout: SwimWorkout
    @EnvironmentObject private var store: ResultsStore

    private var strokeBinding: Binding<Stroke?> {
        Binding(get: { workout.linkedStroke },
                set: { store.setLink(workoutID: workout.id, stroke: $0, pool: workout.linkedPool) })
    }

    private var poolBinding: Binding<Pool?> {
        Binding(get: { workout.linkedPool },
                set: { store.setLink(workoutID: workout.id, stroke: workout.linkedStroke, pool: $0) })
    }

    private var strokeLabel: String {
        if let s = workout.linkedStroke { return s.title }
        if let s = workout.suggestedStroke { return "\(s.title) (авто)" }
        return "Стиль не указан"
    }

    private var poolLabel: String {
        if let p = workout.linkedPool { return "\(p.rawValue) м" }
        if let p = workout.suggestedPool { return "\(p.rawValue) м (авто)" }
        return "Бассейн?"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(workout.startDate, format: .dateTime.day().month(.wide).year())
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                Spacer()
                if let pace = workout.averagePaceSecondsPer100m {
                    Text("\(PaceFormat.clock(pace)) /100 м").font(.caption).foregroundStyle(.secondary).monospacedDigit()
                }
            }
            Text("\(workout.distanceMeters.map { "\(Int($0.rounded())) м" } ?? "—") · \(PaceFormat.clock(workout.durationSeconds))")
                .font(.caption).foregroundStyle(.secondary).monospacedDigit()
            HStack(spacing: 8) {
                Menu {
                    Picker("Стиль", selection: strokeBinding) {
                        Text(workout.suggestedStroke.map { "Авто: \($0.title)" } ?? "Не указан").tag(Stroke?.none)
                        ForEach(Stroke.allCases) { Text($0.title).tag(Stroke?.some($0)) }
                    }
                } label: {
                    Pill(text: strokeLabel, systemImage: "figure.pool.swim",
                         tint: workout.effectiveStroke?.tint ?? .secondary)
                }
                Menu {
                    Picker("Бассейн", selection: poolBinding) {
                        Text(workout.suggestedPool.map { "Авто: \($0.rawValue) м" } ?? "Не указан").tag(Pool?.none)
                        ForEach(Pool.allCases) { Text("\($0.rawValue) м").tag(Pool?.some($0)) }
                    }
                } label: {
                    Pill(text: poolLabel, systemImage: "ruler", tint: workout.effectivePool == nil ? .secondary : Theme.stand)
                }
            }
        }
        .padding(.vertical, 4)
    }
}
